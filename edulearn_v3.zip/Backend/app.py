from flask import Flask, jsonify, request
from flask_restful import Api, Resource, reqparse
from flask_cors import CORS
from llm_api import generate_question, generate_question_feedback, generate_assugnment_feedback, chat
from werkzeug.datastructures import FileStorage
from pdfParsing import parse_PDF
import logging
import datetime
import json

app = Flask(__name__)
cors = CORS(app, origins=['*'])
api = Api(app)

# Configure logging
logging.basicConfig(
    level=logging.DEBUG,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('api_debug.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

def log_request_info(endpoint, method, data=None, files=None):
    """Log detailed request information"""
    timestamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    print(f"\n{'='*60}")
    print(f"🔍 API REQUEST DEBUG - {timestamp}")
    print(f"📍 Endpoint: {method} {endpoint}")
    print(f"🌐 Client IP: {request.remote_addr}")
    print(f"👤 User Agent: {request.headers.get('User-Agent', 'Unknown')}")
    
    if data:
        print(f"📦 Request Data: {json.dumps(data, indent=2)}")
    
    if files:
        print(f"📁 Files Received: {list(files.keys())}")
        for filename, file in files.items():
            print(f"   - {filename}: {file.filename} ({file.content_type})")
    
    print(f"{'='*60}\n")

def log_response_info(endpoint, response_data, status_code=200):
    """Log response information"""
    timestamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    print(f"\n{'='*60}")
    print(f"📤 API RESPONSE DEBUG - {timestamp}")
    print(f"📍 Endpoint: {endpoint}")
    print(f"📊 Status Code: {status_code}")
    print(f"📄 Response Type: {type(response_data)}")
    
    if isinstance(response_data, dict):
        print(f"📦 Response Data: {json.dumps(response_data, indent=2)}")
    else:
        print(f"📦 Response Data: {response_data}")
    
    print(f"{'='*60}\n")



"""
Bellow function is for Generating Question analysis
"""
getQuestion_post_parse = reqparse.RequestParser()
getQuestion_post_parse.add_argument("Topic",type=str,help='Give the topic',required= True)
getQuestion_post_parse.add_argument("Type",type=str,help='Give the Type',required= True)
getQuestion_post_parse.add_argument("Quantity",type=int,help='Give the Quantity',required= True)

#For Generating the questions
class getQuestion(Resource):
    def get(self):
        log_request_info('/getQuestions', 'GET')
        response = {"Reply": "Hosted successfully"}
        log_response_info('/getQuestions', response)
        return jsonify(response)
    
    def post(self):
        print(f"\n🚀 GENERATING QUESTIONS REQUEST")
        log_request_info('/getQuestions', 'POST', data={
            "Topic": request.form.get('Topic'),
            "Type": request.form.get('Type'),
            "Quantity": request.form.get('Quantity')
        })
        
        try:
            data = getQuestion_post_parse.parse_args()
            print(f"✅ Parsed Arguments: Topic='{data['Topic']}', Type='{data['Type']}', Quantity={data['Quantity']}")
            
            print(f"🤖 Calling Gemini AI for question generation...")
            response = generate_question(data["Topic"], data["Type"], data["Quantity"])
            print(f"✅ Questions generated successfully!")
            
            log_response_info('/getQuestions', response)
            return jsonify(response)
            
        except Exception as e:
            error_msg = f"❌ Error generating questions: {str(e)}"
            print(error_msg)
            logger.error(error_msg)
            return jsonify({"error": error_msg}), 500
    

api.add_resource(getQuestion,'/getQuestions')




"""
Bellow function is for Assignment Feedback analysis
"""


getAssignmentFeedback_post_parse = reqparse.RequestParser()
getAssignmentFeedback_post_parse.add_argument("Question",type=FileStorage,location='files',required=True,help="PDF file is required")
getAssignmentFeedback_post_parse.add_argument("Answer",type=FileStorage,location='files',required=True,help="PDF file is required")

class getAssignmentFeedback(Resource):
    def post(self):
        print(f"\n📝 ASSIGNMENT FEEDBACK REQUEST")
        log_request_info('/getAssignmentFeedback', 'POST', files=request.files)
        
        try:
            data = getAssignmentFeedback_post_parse.parse_args()
            Answer_pdf_file = data["Answer"]
            Question_pdf_file = data["Question"]
            
            print(f"📄 Processing PDF files:")
            print(f"   - Question PDF: {Question_pdf_file.filename}")
            print(f"   - Answer PDF: {Answer_pdf_file.filename}")
            
            print(f"🔍 Extracting text from PDFs...")
            Answer_extracted_text = parse_PDF(Answer_pdf_file)
            Question_extracted_text = parse_PDF(Question_pdf_file)
            print(f"✅ Text extraction completed!")
            print(f"   - Question text length: {len(Question_extracted_text)} characters")
            print(f"   - Answer text length: {len(Answer_extracted_text)} characters")
            
            print(f"🤖 Calling Gemini AI for assignment feedback...")
            feedback = generate_assugnment_feedback(Question_extracted_text, Answer_extracted_text)
            print(f"✅ Assignment feedback generated successfully!")
            
            log_response_info('/getAssignmentFeedback', feedback)
            return jsonify(feedback)
            
        except Exception as e:
            error_msg = f"❌ Error processing assignment feedback: {str(e)}"
            print(error_msg)
            logger.error(error_msg)
            return jsonify({"error": error_msg}), 500
    
api.add_resource(getAssignmentFeedback,'/getAssignmentFeedback')








"""
Bellow function is for Quiz Feedback analysis
"""
getQuizFeedback_post_parse = reqparse.RequestParser()

getQuizFeedback_post_parse.add_argument("Questions", type=dict, action='append', location='json', help="Provide list of question objects",required=True)
getQuizFeedback_post_parse.add_argument("Score", type=int, action='append', location='json', help="Provide list of integer scores",required=True)

class getQuizFeedback(Resource):
    def post(self):
        print(f"\n📊 QUIZ FEEDBACK REQUEST")
        log_request_info('/getQuizFeedback', 'POST', data=request.get_json())
        
        try:
            data = getQuizFeedback_post_parse.parse_args()
            print(f"✅ Parsed Quiz Data:")
            print(f"   - Number of questions: {len(data['Questions'])}")
            print(f"   - Number of scores: {len(data['Score'])}")
            print(f"   - Questions: {data['Questions']}")
            print(f"   - Scores: {data['Score']}")
            
            print(f"🤖 Calling Gemini AI for quiz feedback...")
            response = generate_question_feedback(data["Questions"], data["Score"])
            print(f"✅ Quiz feedback generated successfully!")
            
            log_response_info('/getQuizFeedback', response)
            return jsonify(response)
            
        except Exception as e:
            error_msg = f"❌ Error processing quiz feedback: {str(e)}"
            print(error_msg)
            logger.error(error_msg)
            return jsonify({"error": error_msg}), 500
    
api.add_resource(getQuizFeedback,'/getQuizFeedback')

"""
Bellow function is for ChatBot
"""
ChatBot_post_parse = reqparse.RequestParser()
ChatBot_post_parse.add_argument("Message",help = "Send the messeges",required=True)
class ChatBot(Resource):
    def post(self):
        print(f"\n💬 CHATBOT REQUEST")
        log_request_info('/ChatBot', 'POST', data=request.get_json())
        
        try:
            args = ChatBot_post_parse.parse_args()
            user_message = args["Message"]
            print(f"👤 User Message: '{user_message}'")
            
            print(f"🤖 Calling Gemini AI for chatbot response...")
            reply = chat(user_message)
            print(f"✅ Chatbot response generated!")
            print(f"🤖 AI Reply: '{reply}'")
            
            response = {"reply": reply}
            log_response_info('/ChatBot', response)
            return jsonify(response)
            
        except Exception as e:
            error_msg = f"❌ Error in chatbot: {str(e)}"
            print(error_msg)
            logger.error(error_msg)
            return jsonify({"error": error_msg}), 500
    
    def get(self):
        log_request_info('/ChatBot', 'GET')
        response = {"Hello": "Hiii"}
        log_response_info('/ChatBot', response)
        return jsonify(response)
    
api.add_resource(ChatBot,'/ChatBot')






if __name__ == "__main__":
    print(f"\n{'='*60}")
    print(f"🚀 EDULEARNAI BACKEND SERVER STARTING")
    print(f"⏰ Started at: {datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print(f"🌐 Server will run on: http://0.0.0.0:5003")
    print(f"📝 Debug logs will be saved to: api_debug.log")
    print(f"🔍 All API requests will be logged with detailed information")
    print(f"{'='*60}\n")
    
    logger.info("EduLearnAI Backend Server Started")
    app.run(host="0.0.0.0", port='5003', debug=True)
