import google.generativeai as genai
import json
import os
from dotenv import load_dotenv
from prompts import prompt_for_coding,prompt_for_mcq,prompt_for_text_question,feedback_prompt

load_dotenv()

# Configure Gemini AI
api_key = os.getenv("GEMINI_API_KEY")
if api_key:
    genai.configure(api_key=api_key)
    model = genai.GenerativeModel('gemini-1.5-pro')
else:
    print("⚠️  WARNING: GEMINI_API_KEY not found in environment variables")
    model = None

def chat(content):
    print(f"🤖 [GEMINI] Starting chat request...")
    system_prompt = "Just go along with what the user is saying, encourage about studies and give reply in short message format, act like you know about the user and blabber something regarding what they are asking about their academics"
    
    try:
        if not model:
            return "I'm sorry, but the AI service is not configured. Please set up your GEMINI_API_KEY in the .env file."
        
        response = model.generate_content(
            f"{system_prompt}\n\nUser: {content}",
            generation_config=genai.types.GenerationConfig(
                temperature=1.0,
                max_output_tokens=1024,
                top_p=1.0
            )
        )
        print(f"✅ [GEMINI] Chat response generated successfully")
        return response.text
    except Exception as e:
        print(f"❌ [GEMINI] Error in chat: {str(e)}")
        raise e



def callgemini(user_prompt, system_prompt):
    print(f"🤖 [GEMINI] Starting structured request...")
    full_prompt = f"{system_prompt}\n\nUser: {user_prompt}\n\nPlease respond in valid JSON format."
    
    try:
        if not model:
            # Return mock data for testing
            if "MCQ" in user_prompt:
                return json.dumps({
                    "Questions": [
                        {
                            "Question": "What is the primary function of an operating system?",
                            "Options": [
                                "To provide a user interface",
                                "To manage hardware resources and provide services for applications",
                                "To run applications",
                                "To store data"
                            ],
                            "Answer": 1
                        },
                        {
                            "Question": "Which of the following is NOT a type of operating system?",
                            "Options": [
                                "Batch operating system",
                                "Time-sharing operating system",
                                "Distributed operating system",
                                "Web operating system"
                            ],
                            "Answer": 3
                        },
                        {
                            "Question": "What is the main purpose of process scheduling?",
                            "Options": [
                                "To allocate memory to processes",
                                "To manage file systems",
                                "To maximize CPU utilization and minimize response time",
                                "To handle user input"
                            ],
                            "Answer": 2
                        },
                        {
                            "Question": "Which scheduling algorithm is considered the simplest?",
                            "Options": [
                                "Round Robin",
                                "First Come First Serve (FCFS)",
                                "Shortest Job First (SJF)",
                                "Priority Scheduling"
                            ],
                            "Answer": 1
                        },
                        {
                            "Question": "What is virtual memory?",
                            "Options": [
                                "A type of RAM",
                                "A technique that allows the execution of processes that may not be completely in memory",
                                "A backup storage system",
                                "A type of cache memory"
                            ],
                            "Answer": 1
                        }
                    ]
                })
            else:
                return json.dumps({"error": "Mock data not available for this type"})
        
        response = model.generate_content(
            full_prompt,
            generation_config=genai.types.GenerationConfig(
                temperature=0.8,
                max_output_tokens=1910,
                top_p=1.0
            )
        )
        print(f"✅ [GEMINI] Structured response generated successfully")
        return response.text
    except Exception as e:
        print(f"❌ [GEMINI] Error in structured request: {str(e)}")
        raise e


def generate_question(topic,type,questions):
    user_prompt = "user given topic = {topic} and NUMBER OF QUESTIONS = {questions}".format(topic=topic,questions = questions)
    if type=="MCQ":
        answer = callgemini(user_prompt,prompt_for_mcq)
    elif type=='TEXT':
        answer = callgemini(user_prompt,prompt_for_text_question)
    else:
        answer = callgemini(user_prompt,prompt_for_coding)
    parsed = json.loads(answer)
    # print(parsed)
    return parsed



"""
Generating prompt for question analysis
"""





def generate_question_feedback(questions,score):
    user_prompt = "" + "\n\n" + json.dumps({"responses": questions,"scores": score}, indent=2)
    answer = callgemini(user_prompt,feedback_prompt)
    parsed = json.loads(answer)
    return parsed



assignment_feedback_system_prompt = """
Role:
You are an academic evaluator.

Input Format:
The user will provide:
•⁠  ⁠An assignment question (what was asked).
•⁠  ⁠A full assignment answer (student's entire submission as a single string).

Output Format (Strictly respond in this JSON format):
{
  "score_summary": "<e.g., Good effort. Score: 7 out of 10>",
  "what_was_good": "<Brief highlights of strengths in the answer>",
  "what_was_missing_or_wrong": "<Brief areas that need improvement>",
  "suggestions": [
    "<Tip 1>",
    "<Tip 2>"
  ]
}

Rules:
•⁠  ⁠Evaluate the entire assignment holistically (do NOT evaluate question-by-question).
•⁠  ⁠Be concise, constructive, and positive.
•⁠  ⁠Avoid repeating the student’s exact words.
•⁠  ⁠Do NOT include any text outside the JSON object.
"""





def generate_assugnment_feedback(question,answer):
    user_prompt = """
Assignment Question:
{assignment_question}

Assignment Answer:
\"\"\"
{assignment_answer}
\"\"\"
""".format(assignment_answer = answer,assignment_question = question)
    
    answer = callgemini(user_prompt,assignment_feedback_system_prompt)
    parsed = json.loads(answer)
    return parsed
    

    


    
# print(generate_question("OS"))
# generate_question("os")
