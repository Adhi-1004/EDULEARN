import React, { useRef } from 'react';
import { useFrame } from '@react-three/fiber';
import { Box, Text } from '@react-three/drei';
import * as THREE from 'three';

export const FloatingBooks: React.FC = () => {
  const groupRef = useRef<THREE.Group>(null);

  useFrame((state) => {
    if (groupRef.current) {
      groupRef.current.rotation.y = Math.sin(state.clock.elapsedTime * 0.5) * 0.1;
      groupRef.current.position.y = Math.sin(state.clock.elapsedTime * 0.8) * 0.2;
    }
  });

  const books = [
    { position: [0, 0, 0], color: '#3B82F6', title: 'AI' },
    { position: [1.5, 0.5, -0.5], color: '#8B5CF6', title: 'ML' },
    { position: [-1.2, -0.3, 0.8], color: '#EC4899', title: 'DS' },
    { position: [0.8, -0.8, 1.2], color: '#10B981', title: 'WEB' },
  ];

  return (
    <group ref={groupRef}>
      {books.map((book, index) => (
        <group key={index} position={book.position as [number, number, number]}>
          <Box args={[0.8, 1.2, 0.1]} castShadow receiveShadow>
            <meshStandardMaterial color={book.color} />
          </Box>
          <Text
            position={[0, 0, 0.06]}
            fontSize={0.2}
            color="white"
            anchorX="center"
            anchorY="middle"
            font="/fonts/inter-bold.woff"
          >
            {book.title}
          </Text>
        </group>
      ))}
    </group>
  );
};
