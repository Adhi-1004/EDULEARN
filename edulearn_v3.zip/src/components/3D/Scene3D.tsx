import React, { Suspense } from 'react';
import { Canvas } from '@react-three/fiber';
import { OrbitControls, Environment, PerspectiveCamera } from '@react-three/drei';
import { FloatingBooks } from './FloatingBooks';
import { AnimatedGlobe } from './AnimatedGlobe';
import { FloatingIcons } from './FloatingIcons';

interface Scene3DProps {
  type: 'books' | 'globe' | 'icons';
  className?: string;
}

export const Scene3D: React.FC<Scene3DProps> = ({ type, className }) => {
  const renderScene = () => {
    switch (type) {
      case 'books':
        return <FloatingBooks />;
      case 'globe':
        return <AnimatedGlobe />;
      case 'icons':
        return <FloatingIcons />;
      default:
        return <FloatingBooks />;
    }
  };

  return (
    <div className={className}>
      <Canvas shadows>
        <PerspectiveCamera makeDefault position={[0, 0, 5]} />
        <ambientLight intensity={0.5} />
        <directionalLight
          position={[10, 10, 5]}
          intensity={1}
          castShadow
          shadow-mapSize-width={2048}
          shadow-mapSize-height={2048}
        />
        <pointLight position={[-10, -10, -10]} intensity={0.3} />
        
        <Suspense fallback={null}>
          <Environment preset="city" />
          {renderScene()}
        </Suspense>
        
        <OrbitControls
          enableZoom={false}
          enablePan={false}
          autoRotate
          autoRotateSpeed={0.5}
        />
      </Canvas>
    </div>
  );
};
