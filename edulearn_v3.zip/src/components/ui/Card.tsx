import React from 'react';
import { motion } from 'framer-motion';
import { cn } from '../../utils/cn';

interface CardProps {
  children: React.ReactNode;
  className?: string;
  hover?: boolean;
  gradient?: boolean;
  onClick?: () => void;
}

export const Card: React.FC<CardProps> = ({
  children,
  className,
  hover = false,
  gradient = false,
  onClick
}) => {
  const Component = onClick ? motion.div : 'div';
  
  return (
    <Component
      className={cn(
        'bg-white rounded-xl shadow-sm border border-gray-200',
        gradient && 'bg-gradient-to-br from-white to-blue-50 border-blue-200',
        hover && 'hover:shadow-lg transition-all duration-300 cursor-pointer',
        className
      )}
      onClick={onClick}
      {...(onClick && {
        whileHover: { y: -4, scale: 1.02 },
        whileTap: { scale: 0.98 },
        transition: { duration: 0.2 }
      })}
    >
      {children}
    </Component>
  );
};
