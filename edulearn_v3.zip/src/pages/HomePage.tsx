import React, { useState, useEffect, useRef } from 'react';
import { motion, useScroll, useTransform, AnimatePresence } from 'framer-motion';
import { BookOpen, Brain, Users, Award, ArrowRight, Play, CheckCircle, Star, Menu, X, Zap, Target, TrendingUp, GraduationCap, Lightbulb, Rocket, Globe, Code, Calculator, Microscope, Palette, Music, Languages, Camera, Video, Headphones, Gamepad2, Trophy, Medal, Crown, Sparkles } from 'lucide-react';
import { Button } from '../components/ui/Button';
import { Card } from '../components/ui/Card';
import { AuthModal } from '../components/AuthModal';
import { Scene3D } from '../components/3D/Scene3D';
import { useAuth } from '../hooks/useAuth';

export const HomePage: React.FC = () => {
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);
  const [authMode, setAuthMode] = useState<'login' | 'register'>('login');
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [currentFeature, setCurrentFeature] = useState(0);
  const { login } = useAuth();

  const { scrollY } = useScroll();
  const heroY = useTransform(scrollY, [0, 500], [0, -150]);
  const heroOpacity = useTransform(scrollY, [0, 300], [1, 0.3]);

  const featuresRef = useRef<HTMLDivElement>(null);
  const statsRef = useRef<HTMLDivElement>(null);
  const testimonialsRef = useRef<HTMLDivElement>(null);

  const handleAuthSuccess = (userData: any) => {
    login(userData);
    setIsAuthModalOpen(false);
  };

  const openAuthModal = (mode: 'login' | 'register') => {
    setAuthMode(mode);
    setIsAuthModalOpen(true);
  };

  const scrollToSection = (ref: React.RefObject<HTMLDivElement>) => {
    ref.current?.scrollIntoView({ behavior: 'smooth' });
  };

  // Auto-rotate features
  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentFeature((prev) => (prev + 1) % 6);
    }, 4000);
    return () => clearInterval(interval);
  }, []);

  // Floating animation variants
  const floatingAnimation = {
    y: [0, -20, 0],
    transition: {
      duration: 6,
      repeat: Infinity,
      ease: "easeInOut"
    }
  };

  const staggerContainer = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.2
      }
    }
  };

  const fadeInUp = {
    hidden: { opacity: 0, y: 60 },
    visible: {
      opacity: 1,
      y: 0,
      transition: { duration: 0.8, ease: "easeOut" }
    }
  };

  const educationalFeatures = [
    {
      icon: Brain,
      title: 'AI-Powered Learning',
      description: 'Personalized learning paths with intelligent tutoring',
      color: 'from-blue-500 to-cyan-500',
      scene: 'globe'
    },
    {
      icon: Code,
      title: 'Interactive Coding',
      description: 'Real-time coding environment with instant feedback',
      color: 'from-green-500 to-teal-500',
      scene: 'icons'
    },
    {
      icon: Microscope,
      title: 'Virtual Labs',
      description: 'Immersive laboratory experiences from anywhere',
      color: 'from-purple-500 to-pink-500',
      scene: 'books'
    },
    {
      icon: Users,
      title: 'Collaborative Learning',
      description: 'Study groups and peer-to-peer learning',
      color: 'from-orange-500 to-red-500',
      scene: 'globe'
    },
    {
      icon: Trophy,
      title: 'Gamified Progress',
      description: 'Achievements, badges, and leaderboards',
      color: 'from-yellow-500 to-orange-500',
      scene: 'icons'
    },
    {
      icon: TrendingUp,
      title: 'Advanced Analytics',
      description: 'Detailed insights into learning progress',
      color: 'from-indigo-500 to-purple-500',
      scene: 'books'
    }
  ];

  return (
    <div className="min-h-screen bg-white overflow-hidden">
      {/* Navigation */}
      <motion.nav
        initial={{ y: -100 }}
        animate={{ y: 0 }}
        className="fixed top-0 left-0 right-0 z-50 bg-white/90 backdrop-blur-md border-b border-gray-200"
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <motion.div
              whileHover={{ scale: 1.05 }}
              className="flex items-center space-x-2"
            >
              <div className="w-8 h-8 bg-gradient-to-r from-blue-600 to-purple-600 rounded-lg flex items-center justify-center">
                <GraduationCap className="h-5 w-5 text-white" />
              </div>
              <span className="text-xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
                EduLearn AI
              </span>
            </motion.div>

            {/* Desktop Navigation */}
            <div className="hidden md:flex items-center space-x-8">
              <button
                onClick={() => scrollToSection(featuresRef)}
                className="text-gray-600 hover:text-blue-600 transition-colors font-medium"
              >
                Features
              </button>
              <button
                onClick={() => scrollToSection(statsRef)}
                className="text-gray-600 hover:text-blue-600 transition-colors font-medium"
              >
                About
              </button>
              <button
                onClick={() => scrollToSection(testimonialsRef)}
                className="text-gray-600 hover:text-blue-600 transition-colors font-medium"
              >
                Testimonials
              </button>
            </div>

            <div className="hidden md:flex items-center space-x-4">
              <Button
                variant="ghost"
                onClick={() => openAuthModal('login')}
              >
                Sign In
              </Button>
              <Button onClick={() => openAuthModal('register')}>
                Get Started
              </Button>
            </div>

            {/* Mobile menu button */}
            <button
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              className="md:hidden p-2"
            >
              {isMobileMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
            </button>
          </div>
        </div>

        {/* Mobile Navigation */}
        <AnimatePresence>
          {isMobileMenuOpen && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
              className="md:hidden bg-white border-t border-gray-200"
            >
              <div className="px-4 py-4 space-y-4">
                <button
                  onClick={() => {
                    scrollToSection(featuresRef);
                    setIsMobileMenuOpen(false);
                  }}
                  className="block w-full text-left text-gray-600 hover:text-blue-600 font-medium"
                >
                  Features
                </button>
                <button
                  onClick={() => {
                    scrollToSection(statsRef);
                    setIsMobileMenuOpen(false);
                  }}
                  className="block w-full text-left text-gray-600 hover:text-blue-600 font-medium"
                >
                  About
                </button>
                <button
                  onClick={() => {
                    scrollToSection(testimonialsRef);
                    setIsMobileMenuOpen(false);
                  }}
                  className="block w-full text-left text-gray-600 hover:text-blue-600 font-medium"
                >
                  Testimonials
                </button>
                <div className="pt-4 border-t border-gray-200 space-y-2">
                  <Button
                    variant="ghost"
                    className="w-full"
                    onClick={() => openAuthModal('login')}
                  >
                    Sign In
                  </Button>
                  <Button
                    className="w-full"
                    onClick={() => openAuthModal('register')}
                  >
                    Get Started
                  </Button>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </motion.nav>

      {/* Hero Section */}
      <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
        {/* Animated Background */}
        <div className="absolute inset-0 bg-gradient-to-br from-blue-50 via-white to-purple-50">
          {/* Floating Particles */}
          {Array.from({ length: 50 }).map((_, i) => (
            <motion.div
              key={i}
              className="absolute rounded-full bg-gradient-to-r from-blue-400/20 to-purple-400/20"
              style={{
                width: Math.random() * 100 + 20,
                height: Math.random() * 100 + 20,
                left: `${Math.random() * 100}%`,
                top: `${Math.random() * 100}%`,
              }}
              animate={{
                x: [0, Math.random() * 100 - 50],
                y: [0, Math.random() * 100 - 50],
                scale: [1, 1.2, 1],
                opacity: [0.3, 0.6, 0.3],
              }}
              transition={{
                duration: Math.random() * 10 + 10,
                repeat: Infinity,
                ease: "easeInOut",
              }}
            />
          ))}

          {/* Educational Icons Floating */}
          {[BookOpen, Calculator, Microscope, Palette, Music, Languages, Camera, Video, Headphones, Gamepad2].map((Icon, index) => (
            <motion.div
              key={index}
              className="absolute text-blue-400/30"
              style={{
                left: `${10 + (index * 8)}%`,
                top: `${20 + Math.sin(index) * 30}%`,
              }}
              animate={{
                y: [0, -30, 0],
                rotate: [0, 360],
                scale: [1, 1.2, 1],
              }}
              transition={{
                duration: 8 + index,
                repeat: Infinity,
                ease: "easeInOut",
                delay: index * 0.5,
              }}
            >
              <Icon className="h-8 w-8" />
            </motion.div>
          ))}
        </div>

        <motion.div
          style={{ y: heroY, opacity: heroOpacity }}
          className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-20"
        >
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <motion.div
              initial={{ opacity: 0, x: -50 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8 }}
              className="text-center lg:text-left"
            >
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.2 }}
                className="inline-flex items-center px-4 py-2 bg-gradient-to-r from-blue-100 to-purple-100 rounded-full text-blue-800 text-sm font-medium mb-6"
              >
                <Sparkles className="h-4 w-4 mr-2" />
                Next-Generation Learning Platform
              </motion.div>

              <motion.h1
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.4 }}
                className="text-4xl md:text-6xl font-bold text-gray-900 mb-6"
              >
                Transform Your{' '}
                <span className="bg-gradient-to-r from-blue-600 via-purple-600 to-pink-600 bg-clip-text text-transparent">
                  Educational Journey
                </span>
                {' '}with AI
              </motion.h1>

              <motion.p
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.6 }}
                className="text-xl text-gray-600 mb-8 max-w-2xl leading-relaxed"
              >
                Experience the future of education with our comprehensive AI-powered platform. 
                From interactive coding labs to virtual experiments, collaborative study groups to 
                personalized learning paths - everything you need for academic excellence.
              </motion.p>

              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.8 }}
                className="flex flex-col sm:flex-row gap-4 justify-center lg:justify-start mb-8"
              >
                <Button
                  size="lg"
                  onClick={() => openAuthModal('register')}
                  className="group relative overflow-hidden"
                >
                  <span className="relative z-10 flex items-center">
                    Start Learning Free
                    <ArrowRight className="ml-2 h-5 w-5 group-hover:translate-x-1 transition-transform" />
                  </span>
                  <div className="absolute inset-0 bg-gradient-to-r from-blue-700 to-purple-700 transform scale-x-0 group-hover:scale-x-100 transition-transform origin-left" />
                </Button>
                <Button
                  variant="outline"
                  size="lg"
                  onClick={() => scrollToSection(featuresRef)}
                  className="group border-2 border-blue-600 text-blue-600 hover:bg-blue-600 hover:text-white"
                >
                  <Play className="mr-2 h-5 w-5" />
                  Explore Features
                </Button>
              </motion.div>

              {/* Enhanced Stats */}
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 1 }}
                className="grid grid-cols-3 gap-8"
              >
                {[
                  { value: '100K+', label: 'Students', icon: Users },
                  { value: '5K+', label: 'Courses', icon: BookOpen },
                  { value: '99%', label: 'Success Rate', icon: Trophy }
                ].map((stat, index) => (
                  <motion.div
                    key={index}
                    whileHover={{ scale: 1.05 }}
                    className="text-center group"
                  >
                    <div className="flex items-center justify-center mb-2">
                      <div className="w-8 h-8 bg-gradient-to-r from-blue-500 to-purple-500 rounded-lg flex items-center justify-center mr-2 group-hover:scale-110 transition-transform">
                        <stat.icon className="h-4 w-4 text-white" />
                      </div>
                      <div className="text-2xl md:text-3xl font-bold text-gray-900">{stat.value}</div>
                    </div>
                    <div className="text-gray-600 font-medium">{stat.label}</div>
                  </motion.div>
                ))}
              </motion.div>
            </motion.div>

            {/* Enhanced 3D Hero Section */}
            <motion.div
              initial={{ opacity: 0, x: 50 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8, delay: 0.2 }}
              className="relative h-96 lg:h-[500px]"
            >
              <Scene3D 
                type={educationalFeatures[currentFeature].scene as 'books' | 'globe' | 'icons'} 
                className="w-full h-full rounded-2xl"
              />
              
              {/* Feature Indicator */}
              <motion.div
                key={currentFeature}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="absolute bottom-4 left-4 right-4 bg-white/90 backdrop-blur-sm rounded-xl p-4"
              >
                <div className="flex items-center space-x-3">
                  <div className={`w-10 h-10 bg-gradient-to-r ${educationalFeatures[currentFeature].color} rounded-lg flex items-center justify-center`}>
                    <educationalFeatures[currentFeature].icon className="h-5 w-5 text-white" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-gray-900">{educationalFeatures[currentFeature].title}</h3>
                    <p className="text-sm text-gray-600">{educationalFeatures[currentFeature].description}</p>
                  </div>
                </div>
              </motion.div>

              {/* Floating Achievement Badges */}
              <motion.div
                animate={{ ...floatingAnimation, transition: { ...floatingAnimation.transition, delay: 1 } }}
                className="absolute -top-4 -right-4 w-16 h-16 bg-gradient-to-r from-yellow-400 to-orange-500 rounded-full flex items-center justify-center shadow-lg"
              >
                <Crown className="h-8 w-8 text-white" />
              </motion.div>

              <motion.div
                animate={{ ...floatingAnimation, transition: { ...floatingAnimation.transition, delay: 2 } }}
                className="absolute -bottom-4 -left-4 w-12 h-12 bg-gradient-to-r from-green-400 to-blue-500 rounded-full flex items-center justify-center shadow-lg"
              >
                <Medal className="h-6 w-6 text-white" />
              </motion.div>
            </motion.div>
          </div>
        </motion.div>

        {/* Enhanced Scroll Indicator */}
        <motion.div
          animate={{ y: [0, 10, 0] }}
          transition={{ duration: 2, repeat: Infinity }}
          className="absolute bottom-8 left-1/2 transform -translate-x-1/2"
        >
          <button
            onClick={() => scrollToSection(featuresRef)}
            className="flex flex-col items-center text-gray-600 hover:text-blue-600 transition-colors group"
          >
            <span className="text-sm mb-2 font-medium">Discover More</span>
            <div className="w-6 h-10 border-2 border-gray-300 group-hover:border-blue-600 rounded-full flex justify-center transition-colors">
              <motion.div 
                className="w-1 h-3 bg-gray-300 group-hover:bg-blue-600 rounded-full mt-2 transition-colors"
                animate={{ y: [0, 8, 0] }}
                transition={{ duration: 1.5, repeat: Infinity }}
              />
            </div>
          </button>
        </motion.div>
      </section>

      {/* Enhanced Features Section */}
      <section ref={featuresRef} className="py-20 bg-gradient-to-br from-gray-50 to-blue-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            variants={staggerContainer}
            className="text-center mb-16"
          >
            <motion.div variants={fadeInUp}>
              <span className="inline-flex items-center px-4 py-2 bg-blue-100 rounded-full text-blue-800 text-sm font-medium mb-4">
                <Lightbulb className="h-4 w-4 mr-2" />
                Innovative Features
              </span>
            </motion.div>
            <motion.h2 variants={fadeInUp} className="text-3xl md:text-5xl font-bold text-gray-900 mb-6">
              Everything You Need for{' '}
              <span className="bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
                Academic Success
              </span>
            </motion.h2>
            <motion.p variants={fadeInUp} className="text-xl text-gray-600 max-w-3xl mx-auto">
              Our comprehensive platform combines cutting-edge AI technology with proven educational methods
            </motion.p>
          </motion.div>

          <motion.div
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            variants={staggerContainer}
            className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8"
          >
            {[
              {
                icon: Brain,
                title: 'AI-Powered Assessment',
                description: 'Intelligent grading system with detailed feedback and personalized learning recommendations.',
                color: 'from-blue-500 to-cyan-500',
                features: ['Instant Feedback', 'Smart Grading', 'Learning Analytics']
              },
              {
                icon: Code,
                title: 'Interactive Coding Labs',
                description: 'Real-time coding environment with multiple languages and instant execution.',
                color: 'from-green-500 to-teal-500',
                features: ['Multi-language Support', 'Real-time Collaboration', 'Auto-completion']
              },
              {
                icon: Microscope,
                title: 'Virtual Laboratory',
                description: 'Immersive lab experiences with 3D simulations and interactive experiments.',
                color: 'from-purple-500 to-pink-500',
                features: ['3D Simulations', 'Safe Environment', 'Unlimited Resources']
              },
              {
                icon: Users,
                title: 'Study Groups',
                description: 'Collaborative learning spaces with video calls, shared whiteboards, and group projects.',
                color: 'from-orange-500 to-red-500',
                features: ['Video Conferencing', 'Shared Workspace', 'Group Projects']
              },
              {
                icon: Trophy,
                title: 'Gamified Learning',
                description: 'Earn points, badges, and certificates while competing with peers on leaderboards.',
                color: 'from-yellow-500 to-orange-500',
                features: ['Achievement System', 'Leaderboards', 'Certificates']
              },
              {
                icon: TrendingUp,
                title: 'Advanced Analytics',
                description: 'Comprehensive insights into learning progress with predictive analytics.',
                color: 'from-indigo-500 to-purple-500',
                features: ['Progress Tracking', 'Predictive Analytics', 'Performance Reports']
              },
              {
                icon: Globe,
                title: 'Global Classroom',
                description: 'Connect with students worldwide and access international course content.',
                color: 'from-cyan-500 to-blue-500',
                features: ['International Content', 'Cultural Exchange', 'Language Support']
              },
              {
                icon: Rocket,
                title: 'Career Guidance',
                description: 'AI-powered career recommendations and internship opportunities.',
                color: 'from-pink-500 to-rose-500',
                features: ['Career Matching', 'Internship Portal', 'Skill Assessment']
              },
              {
                icon: Target,
                title: 'Personalized Learning',
                description: 'Adaptive learning paths that adjust to your pace and learning style.',
                color: 'from-emerald-500 to-green-500',
                features: ['Adaptive Paths', 'Learning Styles', 'Pace Control']
              }
            ].map((feature, index) => (
              <motion.div key={index} variants={fadeInUp}>
                <Card className="p-6 h-full hover:shadow-xl transition-all duration-300 group relative overflow-hidden">
                  <div className="absolute inset-0 bg-gradient-to-br from-white to-gray-50 opacity-0 group-hover:opacity-100 transition-opacity" />
                  <div className="relative z-10">
                    <div className={`w-12 h-12 bg-gradient-to-r ${feature.color} rounded-lg flex items-center justify-center mb-4 group-hover:scale-110 transition-transform`}>
                      <feature.icon className="h-6 w-6 text-white" />
                    </div>
                    <h3 className="text-xl font-semibold text-gray-900 mb-3">{feature.title}</h3>
                    <p className="text-gray-600 mb-4">{feature.description}</p>
                    <div className="space-y-2">
                      {feature.features.map((item, idx) => (
                        <div key={idx} className="flex items-center text-sm text-gray-500">
                          <CheckCircle className="h-4 w-4 text-green-500 mr-2" />
                          {item}
                        </div>
                      ))}
                    </div>
                  </div>
                </Card>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </section>

      {/* Enhanced Stats Section */}
      <section ref={statsRef} className="py-20 bg-gradient-to-r from-blue-600 via-purple-600 to-pink-600 text-white relative overflow-hidden">
        <div className="absolute inset-0">
          {Array.from({ length: 20 }).map((_, i) => (
            <motion.div
              key={i}
              className="absolute rounded-full bg-white/10"
              style={{
                width: Math.random() * 100 + 50,
                height: Math.random() * 100 + 50,
                left: `${Math.random() * 100}%`,
                top: `${Math.random() * 100}%`,
              }}
              animate={{
                x: [0, Math.random() * 100 - 50],
                y: [0, Math.random() * 100 - 50],
                scale: [1, 1.2, 1],
                opacity: [0.1, 0.3, 0.1],
              }}
              transition={{
                duration: Math.random() * 15 + 10,
                repeat: Infinity,
                ease: "easeInOut",
              }}
            />
          ))}
        </div>

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <motion.div
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            variants={staggerContainer}
            className="text-center mb-12"
          >
            <motion.h2 variants={fadeInUp} className="text-3xl md:text-5xl font-bold mb-6">
              Trusted by Students Worldwide
            </motion.h2>
            <motion.p variants={fadeInUp} className="text-xl text-blue-100 max-w-3xl mx-auto">
              Join millions of learners who have transformed their education with our platform
            </motion.p>
          </motion.div>

          <motion.div
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            variants={staggerContainer}
            className="grid grid-cols-2 md:grid-cols-4 gap-8"
          >
            {[
              { value: '2M+', label: 'Active Students', icon: Users, color: 'from-blue-400 to-cyan-400' },
              { value: '50K+', label: 'Courses Available', icon: BookOpen, color: 'from-green-400 to-emerald-400' },
              { value: '99.2%', label: 'Success Rate', icon: Trophy, color: 'from-yellow-400 to-orange-400' },
              { value: '24/7', label: 'AI Support', icon: Brain, color: 'from-purple-400 to-pink-400' }
            ].map((stat, index) => (
              <motion.div
                key={index}
                variants={fadeInUp}
                className="text-center group"
              >
                <motion.div
                  initial={{ scale: 0 }}
                  whileInView={{ scale: 1 }}
                  transition={{ delay: index * 0.1, type: "spring", stiffness: 100 }}
                  className="relative mb-4"
                >
                  <div className={`w-16 h-16 bg-gradient-to-r ${stat.color} rounded-full flex items-center justify-center mx-auto mb-2 group-hover:scale-110 transition-transform`}>
                    <stat.icon className="h-8 w-8 text-white" />
                  </div>
                  <div className="text-3xl md:text-4xl font-bold mb-2">{stat.value}</div>
                </motion.div>
                <div className="text-blue-100 font-medium">{stat.label}</div>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </section>

      {/* Enhanced Testimonials Section */}
      <section ref={testimonialsRef} className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            variants={staggerContainer}
            className="text-center mb-16"
          >
            <motion.h2 variants={fadeInUp} className="text-3xl md:text-5xl font-bold text-gray-900 mb-6">
              What Our{' '}
              <span className="bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
                Students Say
              </span>
            </motion.h2>
            <motion.p variants={fadeInUp} className="text-xl text-gray-600 max-w-3xl mx-auto">
              Join thousands of satisfied learners who have transformed their education with our platform
            </motion.p>
          </motion.div>

          <motion.div
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            variants={staggerContainer}
            className="grid grid-cols-1 md:grid-cols-3 gap-8"
          >
            {[
              {
                name: 'Sarah Johnson',
                role: 'Computer Science Student, MIT',
                avatar: '/placeholder.svg?height=60&width=60&text=SJ',
                content: 'The AI feedback system helped me improve my coding skills dramatically. The virtual labs made complex algorithms easy to understand. I went from struggling with data structures to acing my exams!',
                rating: 5,
                achievement: 'Top 1% in Algorithms'
              },
              {
                name: 'Dr. Michael Chen',
                role: 'Professor, Stanford University',
                avatar: '/placeholder.svg?height=60&width=60&text=MC',
                content: 'As an educator, I\'ve seen remarkable improvements in student engagement and performance. The analytics help me identify struggling students early and provide targeted support.',
                rating: 5,
                achievement: 'Educator of the Year'
              },
              {
                name: 'Emily Rodriguez',
                role: 'Data Science Student, Berkeley',
                avatar: '/placeholder.svg?height=60&width=60&text=ER',
                content: 'The personalized learning paths and collaborative study groups made complex topics much easier to understand. The career guidance helped me land my dream internship!',
                rating: 5,
                achievement: 'Google Intern 2024'
              }
            ].map((testimonial, index) => (
              <motion.div key={index} variants={fadeInUp}>
                <Card className="p-6 h-full relative overflow-hidden group hover:shadow-xl transition-all duration-300">
                  <div className="absolute top-0 right-0 w-20 h-20 bg-gradient-to-br from-blue-500/10 to-purple-500/10 rounded-full -mr-10 -mt-10 group-hover:scale-150 transition-transform" />
                  <div className="relative z-10">
                    <div className="flex items-center mb-4">
                      {Array.from({ length: testimonial.rating }).map((_, i) => (
                        <Star key={i} className="h-5 w-5 text-yellow-500 fill-current" />
                      ))}
                    </div>
                    <p className="text-gray-600 mb-6 italic leading-relaxed">"{testimonial.content}"</p>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center">
                        <img
                          src={testimonial.avatar || "/placeholder.svg"}
                          alt={testimonial.name}
                          className="w-12 h-12 rounded-full mr-4 border-2 border-blue-200"
                        />
                        <div>
                          <div className="font-semibold text-gray-900">{testimonial.name}</div>
                          <div className="text-gray-600 text-sm">{testimonial.role}</div>
                        </div>
                      </div>
                      <div className="text-right">
                        <div className="text-xs text-blue-600 font-medium bg-blue-100 px-2 py-1 rounded-full">
                          {testimonial.achievement}
                        </div>
                      </div>
                    </div>
                  </div>
                </Card>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </section>

      {/* Enhanced CTA Section */}
      <section className="py-20 bg-gradient-to-r from-blue-600 via-purple-600 to-pink-600 text-white relative overflow-hidden">
        <div className="absolute inset-0">
          {Array.from({ length: 30 }).map((_, i) => (
            <motion.div
              key={i}
              className="absolute"
              style={{
                left: `${Math.random() * 100}%`,
                top: `${Math.random() * 100}%`,
              }}
              animate={{
                y: [0, -100, 0],
                opacity: [0, 1, 0],
              }}
              transition={{
                duration: Math.random() * 3 + 2,
                repeat: Infinity,
                delay: Math.random() * 2,
              }}
            >
              <Sparkles className="h-4 w-4 text-white/30" />
            </motion.div>
          ))}
        </div>

        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center relative z-10">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
          >
            <h2 className="text-3xl md:text-5xl font-bold mb-6">
              Ready to Transform Your{' '}
              <span className="bg-gradient-to-r from-yellow-300 to-orange-300 bg-clip-text text-transparent">
                Learning Experience?
              </span>
            </h2>
            <p className="text-xl text-blue-100 mb-8 max-w-2xl mx-auto leading-relaxed">
              Join millions of students and educators who are already experiencing the future of education. 
              Start your journey today with our comprehensive AI-powered learning platform.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center mb-8">
              <Button
                size="lg"
                variant="secondary"
                onClick={() => openAuthModal('register')}
                className="group relative overflow-hidden bg-white text-blue-600 hover:bg-gray-100"
              >
                <span className="relative z-10 flex items-center">
                  Start Free Trial
                  <ArrowRight className="ml-2 h-5 w-5 group-hover:translate-x-1 transition-transform" />
                </span>
              </Button>
              <Button
                size="lg"
                variant="outline"
                className="border-white text-white hover:bg-white hover:text-blue-600 group"
              >
                <Play className="mr-2 h-5 w-5" />
                Schedule Demo
              </Button>
            </div>
            
            {/* Trust Indicators */}
            <div className="flex flex-wrap justify-center items-center gap-8 opacity-80">
              <div className="flex items-center space-x-2">
                <CheckCircle className="h-5 w-5" />
                <span className="text-sm">No Credit Card Required</span>
              </div>
              <div className="flex items-center space-x-2">
                <CheckCircle className="h-5 w-5" />
                <span className="text-sm">14-Day Free Trial</span>
              </div>
              <div className="flex items-center space-x-2">
                <CheckCircle className="h-5 w-5" />
                <span className="text-sm">Cancel Anytime</span>
              </div>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Enhanced Footer */}
      <footer className="bg-gray-900 text-white py-16 relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-gray-900 via-blue-900/20 to-purple-900/20" />
        
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div className="col-span-1 md:col-span-2">
              <div className="flex items-center space-x-2 mb-4">
                <div className="w-8 h-8 bg-gradient-to-r from-blue-600 to-purple-600 rounded-lg flex items-center justify-center">
                  <GraduationCap className="h-5 w-5 text-white" />
                </div>
                <span className="text-xl font-bold">EduLearn AI</span>
              </div>
              <p className="text-gray-400 mb-6 max-w-md leading-relaxed">
                Empowering learners worldwide with AI-driven education technology. 
                Transform your learning experience and unlock your full potential with our comprehensive platform.
              </p>
              <div className="flex space-x-4">
                {['facebook', 'twitter', 'linkedin', 'instagram', 'youtube'].map((social) => (
                  <motion.a
                    key={social}
                    href="#"
                    whileHover={{ scale: 1.1, y: -2 }}
                    className="w-10 h-10 bg-gray-800 rounded-full flex items-center justify-center hover:bg-blue-600 transition-colors"
                  >
                    <span className="sr-only">{social}</span>
                    <div className="w-5 h-5 bg-current rounded-full"></div>
                  </motion.a>
                ))}
              </div>
            </div>

            <div>
              <h3 className="text-lg font-semibold mb-4">Platform</h3>
              <ul className="space-y-2">
                {['Features', 'Pricing', 'API Documentation', 'Integrations', 'Mobile App'].map((item) => (
                  <li key={item}>
                    <a href="#" className="text-gray-400 hover:text-white transition-colors hover:underline">
                      {item}
                    </a>
                  </li>
                ))}
              </ul>
            </div>

            <div>
              <h3 className="text-lg font-semibold mb-4">Support</h3>
              <ul className="space-y-2">
                {['Help Center', 'Contact Us', 'Community Forum', 'Privacy Policy', 'Terms of Service'].map((item) => (
                  <li key={item}>
                    <a href="#" className="text-gray-400 hover:text-white transition-colors hover:underline">
                      {item}
                    </a>
                  </li>
                ))}
              </ul>
            </div>
          </div>

          <div className="border-t border-gray-800 mt-12 pt-8 flex flex-col md:flex-row justify-between items-center">
            <p className="text-gray-400 text-sm">
              © 2024 EduLearn AI. All rights reserved. Made with ❤️ for learners worldwide.
            </p>
            <div className="flex space-x-6 mt-4 md:mt-0">
              <a href="#" className="text-gray-400 hover:text-white text-sm transition-colors">Privacy</a>
              <a href="#" className="text-gray-400 hover:text-white text-sm transition-colors">Terms</a>
              <a href="#" className="text-gray-400 hover:text-white text-sm transition-colors">Cookies</a>
              <a href="#" className="text-gray-400 hover:text-white text-sm transition-colors">Accessibility</a>
            </div>
          </div>
        </div>
      </footer>

      {/* Auth Modal */}
      <AuthModal
        isOpen={isAuthModalOpen}
        onClose={() => setIsAuthModalOpen(false)}
        onLogin={handleAuthSuccess}
        initialMode={authMode}
      />
    </div>
  );
};
