import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useParams, useNavigate } from 'react-router-dom';
import Editor from '@monaco-editor/react';
import { Play, Send, Camera, CameraOff, Moon, Sun, ChevronLeft, ChevronRight, Clock, Trophy, Target, AlertTriangle, CheckCircle, X } from 'lucide-react';
import { Button } from '../../components/ui/Button';
import { Card } from '../../components/ui/Card';
import { CameraMonitor } from '../../components/CameraMonitor';
import { Leaderboard } from '../../components/Leaderboard';
import { Modal } from '../../components/ui/Modal';
import { CodingProblem, LeaderboardEntry } from '../../types';

export const CodingEnvironment: React.FC = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  
  const [currentProblem, setCurrentProblem] = useState<CodingProblem | null>(null);
  const [language, setLanguage] = useState('javascript');
  const [code, setCode] = useState('');
  const [output, setOutput] = useState('');
  const [isRunning, setIsRunning] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isDarkMode, setIsDarkMode] = useState(true);
  const [showProblem, setShowProblem] = useState(true);
  const [problemWidth, setProblemWidth] = useState(33);
  const [activeTab, setActiveTab] = useState('description');
  const [editorTab, setEditorTab] = useState('code');
  const [testResults, setTestResults] = useState<any[]>([]);
  const [timeLeft, setTimeLeft] = useState(3600); // 1 hour
  const [isTestStarted, setIsTestStarted] = useState(false);
  const [isCameraActive, setIsCameraActive] = useState(false);
  const [violations, setViolations] = useState<string[]>([]);
  const [showLeaderboard, setShowLeaderboard] = useState(false);
  const [isTestCompleted, setIsTestCompleted] = useState(false);
  const [resizing, setResizing] = useState(false);

  const containerRef = useRef<HTMLDivElement>(null);

  // Mock problem data
  const mockProblem: CodingProblem = {
    id: '1',
    title: 'Two Sum',
    difficulty: 'Easy',
    description: 'Given an array of integers nums and an integer target, return indices of the two numbers such that they add up to target.',
    examples: [
      {
        input: 'nums = [2,7,11,15], target = 9',
        output: '[0,1]',
        explanation: 'Because nums[0] + nums[1] == 9, we return [0, 1].'
      }
    ],
    constraints: [
      '2 <= nums.length <= 10^4',
      '-10^9 <= nums[i] <= 10^9',
      'Only one valid answer exists.'
    ],
    testCases: [
      { input: '[2,7,11,15], 9', expectedOutput: '[0,1]' },
      { input: '[3,2,4], 6', expectedOutput: '[1,2]' }
    ],
    starterCode: {
      javascript: `/**
 * @param {number[]} nums
 * @param {number} target
 * @return {number[]}
 */
function twoSum(nums, target) {
    // Your code here
}`,
      python: `class Solution:
    def twoSum(self, nums: List[int], target: int) -> List[int]:
        # Your code here
        pass`
    }
  };

  // Mock leaderboard data
  const [leaderboardData] = useState<LeaderboardEntry[]>([
    {
      rank: 1,
      studentId: '1',
      studentName: 'Alice Johnson',
      score: 100,
      timeSpent: 1245,
      avatar: '/placeholder.svg?height=40&width=40&text=AJ'
    },
    {
      rank: 2,
      studentId: '2',
      studentName: 'Bob Smith',
      score: 95,
      timeSpent: 1380,
      avatar: '/placeholder.svg?height=40&width=40&text=BS'
    },
    {
      rank: 3,
      studentId: '3',
      studentName: 'Carol Davis',
      score: 90,
      timeSpent: 1520,
      avatar: '/placeholder.svg?height=40&width=40&text=CD'
    }
  ]);

  useEffect(() => {
    setCurrentProblem(mockProblem);
    setCode(mockProblem.starterCode[language] || '');
  }, [language]);

  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (isTestStarted && timeLeft > 0 && !isTestCompleted) {
      interval = setInterval(() => {
        setTimeLeft(prev => {
          if (prev <= 1) {
            handleTimeUp();
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [isTestStarted, timeLeft, isTestCompleted]);

  const formatTime = (seconds: number) => {
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    const secs = seconds % 60;
    return `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const handleStartTest = () => {
    setIsTestStarted(true);
    setIsCameraActive(true);
  };

  const handleTimeUp = () => {
    setIsTestCompleted(true);
    setIsCameraActive(false);
    setShowLeaderboard(true);
  };

  const handleViolation = (type: string) => {
    setViolations(prev => [...prev, type]);
    // In a real implementation, you might want to take action based on violations
  };

  const handleRun = async () => {
    setIsRunning(true);
    setOutput('');
    setTestResults([]);

    try {
      await new Promise(resolve => setTimeout(resolve, 1000));

      const results = currentProblem?.testCases.map((testCase, index) => {
        const passed = Math.random() > 0.3; // Mock result
        return {
          passed,
          input: testCase.input,
          expected: testCase.expectedOutput,
          actual: passed ? testCase.expectedOutput : 'Wrong output',
        };
      }) || [];

      setTestResults(results);
      setEditorTab('result');
    } catch (error) {
      setOutput('Error: ' + (error as Error).message);
    } finally {
      setIsRunning(false);
    }
  };

  const handleSubmit = async () => {
    setIsSubmitting(true);
    
    try {
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      const allPassed = testResults.every(result => result.passed);
      if (allPassed) {
        setIsTestCompleted(true);
        setIsCameraActive(false);
        setShowLeaderboard(true);
      }
    } finally {
      setIsSubmitting(false);
    }
  };

  const renderEditorContent = () => {
    switch (editorTab) {
      case 'code':
        return (
          <Editor
            height="100%"
            defaultLanguage={language}
            value={code}
            onChange={(val) => setCode(val || '')}
            theme={isDarkMode ? 'vs-dark' : 'light'}
            options={{
              minimap: { enabled: false },
              fontSize: 14,
              scrollBeyondLastLine: false,
              automaticLayout: true,
              lineNumbers: 'on',
              tabSize: 2,
              wordWrap: 'on',
            }}
          />
        );
      case 'testcase':
        return (
          <div className={`p-4 h-full overflow-auto ${isDarkMode ? 'bg-[#1e1e1e] text-white' : 'bg-white text-gray-900'}`}>
            <h3 className="text-lg font-medium mb-4">Test Cases</h3>
            <div className="space-y-4">
              {currentProblem?.testCases.map((testCase, index) => (
                <div key={index} className={`p-4 rounded-md ${isDarkMode ? 'bg-gray-800' : 'bg-gray-100'}`}>
                  <div className="font-mono mb-2">
                    <span className="font-semibold">Input:</span> {testCase.input}
                  </div>
                  <div className="font-mono">
                    <span className="font-semibold">Expected Output:</span> {testCase.expectedOutput}
                  </div>
                </div>
              ))}
            </div>
          </div>
        );
      case 'result':
        return (
          <div className={`p-4 h-full overflow-auto ${isDarkMode ? 'bg-[#1e1e1e] text-white' : 'bg-white text-gray-900'}`}>
            <h3 className="text-lg font-medium mb-4">Test Results</h3>
            {testResults.length > 0 ? (
              <div className="space-y-4">
                {testResults.map((result, index) => (
                  <div
                    key={index}
                    className={`p-4 rounded-md ${
                      result.passed
                        ? isDarkMode ? 'bg-green-900/30' : 'bg-green-100'
                        : isDarkMode ? 'bg-red-900/30' : 'bg-red-100'
                    }`}
                  >
                    <div className="flex items-center mb-2">
                      <span className={`mr-2 ${result.passed ? 'text-green-500' : 'text-red-500'}`}>
                        {result.passed ? <CheckCircle className="h-5 w-5" /> : <X className="h-5 w-5" />}
                      </span>
                      <span className="font-medium">
                        Test Case {index + 1}: {result.passed ? 'PASSED' : 'FAILED'}
                      </span>
                    </div>
                    <div className="font-mono text-sm space-y-1">
                      <div><span className="font-semibold">Input:</span> {result.input}</div>
                      <div><span className="font-semibold">Expected:</span> {result.expected}</div>
                      <div><span className="font-semibold">Actual:</span> {result.actual}</div>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className={`text-center py-8 ${isDarkMode ? 'text-gray-400' : 'text-gray-500'}`}>
                Run your code to see results
              </div>
            )}
          </div>
        );
      default:
        return null;
    }
  };

  if (!isTestStarted) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <Card className="p-8 max-w-md w-full text-center">
          <div className="mb-6">
            <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <Trophy className="h-8 w-8 text-blue-600" />
            </div>
            <h2 className="text-2xl font-bold text-gray-900 mb-2">Coding Challenge</h2>
            <p className="text-gray-600">
              You are about to start a timed coding challenge. Your camera will be monitored for security purposes.
            </p>
          </div>

          <div className="space-y-4 mb-6">
            <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
              <span className="text-gray-600">Duration:</span>
              <span className="font-semibold">{formatTime(timeLeft)}</span>
            </div>
            <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
              <span className="text-gray-600">Problems:</span>
              <span className="font-semibold">1</span>
            </div>
            <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
              <span className="text-gray-600">Camera Monitoring:</span>
              <span className="font-semibold text-green-600">Required</span>
            </div>
          </div>

          <Button onClick={handleStartTest} className="w-full">
            <Camera className="h-4 w-4 mr-2" />
            Start Test
          </Button>
        </Card>
      </div>
    );
  }

  return (
    <div className={`flex flex-col h-screen ${isDarkMode ? 'bg-[#1a1a1a] text-white' : 'bg-white text-gray-900'}`}>
      {/* Header */}
      <header className={`flex items-center justify-between px-4 py-2 border-b ${isDarkMode ? 'bg-[#1a1a1a] border-gray-800' : 'bg-white border-gray-200'}`}>
        <div className="flex items-center space-x-4">
          <h1 className="text-lg font-semibold">Coding Challenge</h1>
          <div className="flex items-center space-x-2 px-3 py-1 bg-blue-100 rounded-full">
            <Clock className="h-4 w-4 text-blue-600" />
            <span className="text-blue-600 font-medium">{formatTime(timeLeft)}</span>
          </div>
        </div>

        <div className="flex items-center space-x-3">
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setIsDarkMode(!isDarkMode)}
          >
            {isDarkMode ? <Sun className="h-4 w-4" /> : <Moon className="h-4 w-4" />}
          </Button>

          <select
            value={language}
            onChange={(e) => setLanguage(e.target.value)}
            className={`px-3 py-1.5 rounded-md text-sm border ${
              isDarkMode ? 'bg-gray-800 border-gray-700 text-white' : 'bg-white border-gray-300 text-gray-900'
            }`}
          >
            <option value="javascript">JavaScript</option>
            <option value="python">Python</option>
          </select>

          <Button
            onClick={handleRun}
            disabled={isRunning}
            size="sm"
            variant="outline"
          >
            <Play className="h-4 w-4 mr-1" />
            {isRunning ? 'Running...' : 'Run'}
          </Button>

          <Button
            onClick={handleSubmit}
            disabled={isSubmitting}
            size="sm"
          >
            <Send className="h-4 w-4 mr-1" />
            {isSubmitting ? 'Submitting...' : 'Submit'}
          </Button>
        </div>
      </header>

      {/* Main Content */}
      <div className="flex-1 flex overflow-hidden relative" ref={containerRef}>
        {/* Problem Description */}
        <AnimatePresence>
          {showProblem && (
            <motion.div
              className={`overflow-y-auto border-r ${isDarkMode ? 'bg-[#1a1a1a] border-gray-800' : 'bg-white border-gray-200'}`}
              style={{ width: `${problemWidth}%` }}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
            >
              <div className={`flex border-b ${isDarkMode ? 'border-gray-800' : 'border-gray-200'}`}>
                <button
                  onClick={() => setActiveTab('description')}
                  className={`px-4 py-2 font-medium text-sm ${
                    activeTab === 'description'
                      ? isDarkMode ? 'border-b-2 border-blue-500 text-blue-500' : 'border-b-2 border-blue-600 text-blue-600'
                      : isDarkMode ? 'text-gray-400 hover:text-gray-300' : 'text-gray-600 hover:text-gray-800'
                  }`}
                >
                  Description
                </button>
              </div>

              <div className="p-6">
                <div className="flex justify-between items-center mb-4">
                  <h1 className={`text-xl font-semibold ${isDarkMode ? 'text-white' : 'text-gray-900'}`}>
                    {currentProblem?.title}
                  </h1>
                  <span className={`px-2 py-1 rounded text-xs font-medium ${
                    currentProblem?.difficulty === 'Easy' ? 'bg-green-100 text-green-800' :
                    currentProblem?.difficulty === 'Medium' ? 'bg-yellow-100 text-yellow-800' :
                    'bg-red-100 text-red-800'
                  }`}>
                    {currentProblem?.difficulty}
                  </span>
                </div>

                <div className={`mb-6 ${isDarkMode ? 'text-gray-300' : 'text-gray-700'}`}>
                  <p>{currentProblem?.description}</p>
                </div>

                <div className="mb-6">
                  <h3 className={`text-lg font-medium mb-3 ${isDarkMode ? 'text-white' : 'text-gray-900'}`}>
                    Examples:
                  </h3>
                  {currentProblem?.examples.map((example, index) => (
                    <div key={index} className={`p-4 rounded-md mb-3 ${isDarkMode ? 'bg-gray-800' : 'bg-gray-50'}`}>
                      <div className={`mb-1 ${isDarkMode ? 'text-gray-300' : 'text-gray-700'}`}>
                        <span className="font-mono">Input: </span>
                        <span>{example.input}</span>
                      </div>
                      <div className={`mb-1 ${isDarkMode ? 'text-gray-300' : 'text-gray-700'}`}>
                        <span className="font-mono">Output: </span>
                        <span>{example.output}</span>
                      </div>
                      {example.explanation && (
                        <div className={`${isDarkMode ? 'text-gray-400' : 'text-gray-600'}`}>
                          <span className="font-mono">Explanation: </span>
                          <span>{example.explanation}</span>
                        </div>
                      )}
                    </div>
                  ))}
                </div>

                <div>
                  <h3 className={`text-lg font-medium mb-2 ${isDarkMode ? 'text-white' : 'text-gray-900'}`}>
                    Constraints:
                  </h3>
                  <ul className={`list-disc pl-5 ${isDarkMode ? 'text-gray-300' : 'text-gray-700'}`}>
                    {currentProblem?.constraints.map((constraint, index) => (
                      <li key={index} className="mb-1 font-mono text-sm">
                        {constraint}
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Toggle Problem Button */}
        <button
          onClick={() => setShowProblem(!showProblem)}
          className={`absolute top-1/2 ${showProblem ? 'left-[33%]' : 'left-0'} z-20 p-1 rounded-r-md ${
            isDarkMode ? 'bg-gray-800 hover:bg-gray-700 text-gray-300' : 'bg-gray-200 hover:bg-gray-300 text-gray-700'
          }`}
          style={{ transform: 'translateY(-50%)' }}
        >
          {showProblem ? <ChevronLeft className="h-4 w-4" /> : <ChevronRight className="h-4 w-4" />}
        </button>

        {/* Code Editor Section */}
        <div className="flex flex-col flex-1">
          <div className={`flex border-b ${isDarkMode ? 'border-gray-800 bg-[#1e1e1e]' : 'border-gray-200 bg-gray-50'}`}>
            <button
              onClick={() => setEditorTab('code')}
              className={`px-4 py-2 font-medium text-sm ${
                editorTab === 'code'
                  ? isDarkMode ? 'border-b-2 border-blue-500 text-blue-500' : 'border-b-2 border-blue-600 text-blue-600'
                  : isDarkMode ? 'text-gray-400 hover:text-gray-300' : 'text-gray-600 hover:text-gray-800'
              }`}
            >
              Code
            </button>
            <button
              onClick={() => setEditorTab('testcase')}
              className={`px-4 py-2 font-medium text-sm ${
                editorTab === 'testcase'
                  ? isDarkMode ? 'border-b-2 border-blue-500 text-blue-500' : 'border-b-2 border-blue-600 text-blue-600'
                  : isDarkMode ? 'text-gray-400 hover:text-gray-300' : 'text-gray-600 hover:text-gray-800'
              }`}
            >
              Test Cases
            </button>
            <button
              onClick={() => setEditorTab('result')}
              className={`px-4 py-2 font-medium text-sm ${
                editorTab === 'result'
                  ? isDarkMode ? 'border-b-2 border-blue-500 text-blue-500' : 'border-b-2 border-blue-600 text-blue-600'
                  : isDarkMode ? 'text-gray-400 hover:text-gray-300' : 'text-gray-600 hover:text-gray-800'
              }`}
            >
              Results
            </button>
          </div>

          <div className="flex-1 overflow-hidden">
            {renderEditorContent()}
          </div>
        </div>
      </div>

      {/* Camera Monitor */}
      <CameraMonitor
        isActive={isCameraActive}
        onViolation={handleViolation}
      />

      {/* Violations Alert */}
      {violations.length > 0 && (
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          animate={{ opacity: 1, y: 0 }}
          className="fixed bottom-4 left-4 bg-red-500 text-white p-4 rounded-lg shadow-lg"
        >
          <div className="flex items-center">
            <AlertTriangle className="h-5 w-5 mr-2" />
            <span>Security violation detected: {violations[violations.length - 1]}</span>
          </div>
        </motion.div>
      )}

      {/* Leaderboard Modal */}
      <Modal
        isOpen={showLeaderboard}
        onClose={() => setShowLeaderboard(false)}
        title="Test Results & Leaderboard"
        size="lg"
      >
        <div className="space-y-6">
          <div className="text-center">
            <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <Trophy className="h-8 w-8 text-green-600" />
            </div>
            <h3 className="text-xl font-semibold text-gray-900 mb-2">Test Completed!</h3>
            <p className="text-gray-600">Great job! Here's how you performed compared to others.</p>
          </div>

          <Leaderboard
            entries={leaderboardData}
            currentUserId="current-user"
            title="Challenge Leaderboard"
          />

          <div className="flex justify-center space-x-4">
            <Button onClick={() => navigate('/student/dashboard')}>
              Back to Dashboard
            </Button>
            <Button variant="outline" onClick={() => setShowLeaderboard(false)}>
              Review Solution
            </Button>
          </div>
        </div>
      </Modal>
    </div>
  );
};
