import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useNavigate } from 'react-router-dom';
import { BookOpen, Code, FileText, TrendingUp, Award, Clock, Target, Brain, Users, Calendar, Bell, Search, Filter, MoreVertical, Play, CheckCircle, AlertCircle, Star, GraduationCap, Microscope, MessageSquare, Library, Briefcase, UserCheck, Notebook, Video, Headphones, Globe, Zap, Trophy, Medal, Crown, Sparkles, ChevronRight, Plus, Download, Share, Eye, Heart, ThumbsUp, Coffee, Moon, Sun, Settings, HelpCircle, LogOut } from 'lucide-react';
import { Card } from '../../components/ui/Card';
import { Button } from '../../components/ui/Button';
import { Scene3D } from '../../components/3D/Scene3D';
import { User, Assignment, StudyMaterial, VirtualLab, Discussion, Attendance, Grade, StudyGroup, Certificate, Project, Internship, CalendarEvent, Note, LibraryBook } from '../../types';

interface StudentDashboardProps {
  user: User;
  onLogout: () => void;
}

export const StudentDashboard: React.FC<StudentDashboardProps> = ({ user, onLogout }) => {
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState('overview');
  const [searchQuery, setSearchQuery] = useState('');
  const [filterStatus, setFilterStatus] = useState('all');
  const [isDarkMode, setIsDarkMode] = useState(false);
  const [currentTime, setCurrentTime] = useState(new Date());

  // Update time every minute
  useEffect(() => {
    const timer = setInterval(() => setCurrentTime(new Date()), 60000);
    return () => clearInterval(timer);
  }, []);

  // Mock comprehensive data
  const [assignments] = useState<Assignment[]>([
    {
      id: '1',
      title: 'Data Structures Implementation',
      subject: 'Computer Science',
      description: 'Implement various data structures including linked lists, stacks, and queues with comprehensive testing.',
      dueDate: '2024-01-20',
      status: 'pending',
      maxGrade: 100,
      attachments: ['requirements.pdf', 'starter_code.zip']
    },
    {
      id: '2',
      title: 'Machine Learning Project',
      subject: 'Artificial Intelligence',
      description: 'Build a classification model using supervised learning techniques with real-world dataset.',
      dueDate: '2024-01-25',
      status: 'pending',
      maxGrade: 100
    },
    {
      id: '3',
      title: 'Database Design Assignment',
      subject: 'Database Systems',
      description: 'Design and implement a normalized database schema for an e-commerce platform.',
      dueDate: '2024-01-15',
      status: 'completed',
      grade: 92,
      maxGrade: 100,
      feedback: 'Excellent work on normalization! Consider adding more indexes for performance.'
    }
  ]);

  const [studyMaterials] = useState<StudyMaterial[]>([
    {
      id: '1',
      title: 'Advanced Algorithms Lecture Series',
      subject: 'Computer Science',
      type: 'video',
      url: '#',
      description: 'Comprehensive video series covering advanced algorithmic concepts',
      uploadDate: '2024-01-10',
      duration: '4h 30m',
      tags: ['algorithms', 'complexity', 'optimization']
    },
    {
      id: '2',
      title: 'Machine Learning Fundamentals',
      subject: 'AI',
      type: 'pdf',
      url: '#',
      description: 'Complete guide to machine learning concepts and implementations',
      uploadDate: '2024-01-08',
      size: '15.2 MB',
      tags: ['ml', 'python', 'statistics']
    }
  ]);

  const [virtualLabs] = useState<VirtualLab[]>([
    {
      id: '1',
      title: 'Chemistry Virtual Lab',
      subject: 'Chemistry',
      description: 'Interactive chemistry experiments in a safe virtual environment',
      type: 'simulation',
      difficulty: 'Intermediate',
      estimatedTime: 120,
      prerequisites: ['Basic Chemistry', 'Lab Safety'],
      learningOutcomes: ['Chemical Reactions', 'Lab Techniques', 'Safety Protocols']
    },
    {
      id: '2',
      title: 'Physics Simulation Lab',
      subject: 'Physics',
      description: 'Explore physics concepts through interactive simulations',
      type: 'simulation',
      difficulty: 'Advanced',
      estimatedTime: 90,
      prerequisites: ['Calculus', 'Basic Physics'],
      learningOutcomes: ['Wave Mechanics', 'Quantum Physics', 'Experimental Design']
    }
  ]);

  const [discussions] = useState<Discussion[]>([
    {
      id: '1',
      title: 'Help with Dynamic Programming',
      content: 'Can someone explain the optimal substructure property?',
      author: 'Alice Johnson',
      authorId: '1',
      subject: 'Algorithms',
      createdAt: '2024-01-12T10:30:00Z',
      replies: [],
      likes: 15,
      views: 234,
      tags: ['algorithms', 'dynamic-programming', 'help']
    }
  ]);

  const [attendance] = useState<Attendance[]>([
    {
      id: '1',
      subject: 'Computer Science',
      date: '2024-01-15',
      status: 'present',
      duration: 90,
      topic: 'Advanced Data Structures'
    }
  ]);

  const [grades] = useState<Grade[]>([
    {
      id: '1',
      subject: 'Computer Science',
      assessment: 'Midterm Exam',
      marks: 85,
      maxMarks: 100,
      grade: 'A',
      date: '2024-01-10',
      feedback: 'Good understanding of concepts'
    }
  ]);

  const [studyGroups] = useState<StudyGroup[]>([
    {
      id: '1',
      name: 'AI Study Circle',
      subject: 'Artificial Intelligence',
      description: 'Weekly discussions on AI concepts and projects',
      members: ['Alice', 'Bob', 'Charlie'],
      createdBy: 'Alice',
      createdAt: '2024-01-01',
      nextMeeting: '2024-01-20T15:00:00Z'
    }
  ]);

  const [certificates] = useState<Certificate[]>([
    {
      id: '1',
      title: 'Python Programming Certification',
      description: 'Advanced Python programming skills certification',
      issuedDate: '2024-01-01',
      credentialId: 'PY2024001',
      skills: ['Python', 'OOP', 'Data Structures'],
      issuer: 'EduLearn AI'
    }
  ]);

  const [projects] = useState<Project[]>([
    {
      id: '1',
      title: 'E-commerce Platform',
      description: 'Full-stack web application with React and Node.js',
      subject: 'Web Development',
      teamMembers: ['You', 'Alice', 'Bob'],
      status: 'in-progress',
      dueDate: '2024-02-15',
      progress: 65,
      repository: 'https://github.com/team/ecommerce'
    }
  ]);

  const [internships] = useState<Internship[]>([
    {
      id: '1',
      company: 'Tech Corp',
      position: 'Software Development Intern',
      description: 'Work on cutting-edge web applications',
      requirements: ['React', 'Node.js', 'Database'],
      duration: '3 months',
      stipend: '$2000/month',
      location: 'Remote',
      applicationDeadline: '2024-02-01',
      status: 'open'
    }
  ]);

  const [upcomingEvents] = useState<CalendarEvent[]>([
    {
      id: '1',
      title: 'AI Workshop',
      date: '2024-01-22',
      time: '14:00',
      type: 'event',
      subject: 'Artificial Intelligence',
      location: 'Virtual'
    }
  ]);

  const [notes] = useState<Note[]>([
    {
      id: '1',
      title: 'Algorithm Complexity Notes',
      content: 'Big O notation and complexity analysis...',
      subject: 'Computer Science',
      tags: ['algorithms', 'complexity'],
      createdAt: '2024-01-10',
      updatedAt: '2024-01-12',
      isShared: false
    }
  ]);

  const [libraryBooks] = useState<LibraryBook[]>([
    {
      id: '1',
      title: 'Introduction to Algorithms',
      author: 'Cormen, Leiserson, Rivest, Stein',
      isbn: '978-0262033848',
      subject: 'Computer Science',
      description: 'Comprehensive guide to algorithms and data structures',
      availableCopies: 3,
      totalCopies: 5,
      status: 'available'
    }
  ]);

  const [stats] = useState({
    completedAssignments: 12,
    totalAssignments: 15,
    averageGrade: 87,
    currentStreak: 7,
    totalPoints: 2450,
    rank: 23,
    studyHours: 156,
    certificatesEarned: 3,
    projectsCompleted: 8,
    attendanceRate: 94
  });

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'completed':
        return 'bg-green-100 text-green-800 border-green-200';
      case 'pending':
        return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      case 'overdue':
        return 'bg-red-100 text-red-800 border-red-200';
      case 'in-progress':
        return 'bg-blue-100 text-blue-800 border-blue-200';
      default:
        return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case 'Beginner':
        return 'bg-green-100 text-green-800';
      case 'Intermediate':
        return 'bg-yellow-100 text-yellow-800';
      case 'Advanced':
        return 'bg-red-100 text-red-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const filteredAssignments = assignments.filter(assignment => {
    const matchesSearch = assignment.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         assignment.subject.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesFilter = filterStatus === 'all' || assignment.status === filterStatus;
    return matchesSearch && matchesFilter;
  });

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1
      }
    }
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: { duration: 0.5 }
    }
  };

  const tabItems = [
    { id: 'overview', label: 'Overview', icon: BookOpen },
    { id: 'assignments', label: 'Assignments', icon: FileText },
    { id: 'coding', label: 'Coding Labs', icon: Code },
    { id: 'mcq', label: 'MCQ Tests', icon: Brain },
    { id: 'materials', label: 'Study Materials', icon: Library },
    { id: 'labs', label: 'Virtual Labs', icon: Microscope },
    { id: 'discussions', label: 'Discussions', icon: MessageSquare },
    { id: 'groups', label: 'Study Groups', icon: Users },
    { id: 'projects', label: 'Projects', icon: Briefcase },
    { id: 'internships', label: 'Internships', icon: UserCheck },
    { id: 'notes', label: 'My Notes', icon: Notebook },
    { id: 'library', label: 'Library', icon: Library },
    { id: 'certificates', label: 'Certificates', icon: Award }
  ];

  return (
    <div className={`min-h-screen transition-colors duration-300 ${isDarkMode ? 'bg-gray-900 text-white' : 'bg-gray-50 text-gray-900'}`}>
      {/* Enhanced Header */}
      <header className={`shadow-sm border-b transition-colors duration-300 ${isDarkMode ? 'bg-gray-800 border-gray-700' : 'bg-white border-gray-200'}`}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-2">
                <div className="w-8 h-8 bg-gradient-to-r from-blue-600 to-purple-600 rounded-lg flex items-center justify-center">
                  <GraduationCap className="h-5 w-5 text-white" />
                </div>
                <span className="text-xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
                  EduLearn AI
                </span>
              </div>
              <div className={`hidden md:block h-6 w-px ${isDarkMode ? 'bg-gray-600' : 'bg-gray-300'}`} />
              <h1 className="hidden md:block text-lg font-semibold">Student Dashboard</h1>
            </div>

            <div className="flex items-center space-x-4">
              <div className="relative">
                <Search className={`absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 ${isDarkMode ? 'text-gray-400' : 'text-gray-400'}`} />
                <input
                  type="text"
                  placeholder="Search anything..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className={`pl-10 pr-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 w-64 transition-colors ${
                    isDarkMode ? 'bg-gray-700 border-gray-600 text-white placeholder-gray-400' : 'bg-white border-gray-300 text-gray-900'
                  }`}
                />
              </div>

              <button
                onClick={() => setIsDarkMode(!isDarkMode)}
                className={`p-2 rounded-lg transition-colors ${isDarkMode ? 'text-gray-300 hover:text-white hover:bg-gray-700' : 'text-gray-600 hover:text-blue-600 hover:bg-gray-100'}`}
              >
                {isDarkMode ? <Sun className="h-5 w-5" /> : <Moon className="h-5 w-5" />}
              </button>

              <button className={`relative p-2 rounded-lg transition-colors ${isDarkMode ? 'text-gray-300 hover:text-white hover:bg-gray-700' : 'text-gray-600 hover:text-blue-600 hover:bg-gray-100'}`}>
                <Bell className="h-6 w-6" />
                <span className="absolute top-0 right-0 h-2 w-2 bg-red-500 rounded-full"></span>
              </button>

              <div className="flex items-center space-x-3">
                <div className="w-8 h-8 bg-gradient-to-r from-blue-500 to-purple-500 rounded-full flex items-center justify-center">
                  <span className="text-white font-medium text-sm">
                    {user.name.split(' ').map(n => n[0]).join('')}
                  </span>
                </div>
                <div className="hidden md:block">
                  <p className={`text-sm font-medium ${isDarkMode ? 'text-white' : 'text-gray-900'}`}>{user.name}</p>
                  <p className={`text-xs ${isDarkMode ? 'text-gray-400' : 'text-gray-500'}`}>
                    {user.department} • Year {user.year}
                  </p>
                </div>
              </div>

              <Button variant="ghost" onClick={onLogout} className="text-red-600 hover:text-red-700 hover:bg-red-50">
                <LogOut className="h-4 w-4 mr-2" />
                Logout
              </Button>
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Enhanced Welcome Section */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8"
        >
          <div className="relative overflow-hidden bg-gradient-to-r from-blue-600 via-purple-600 to-pink-600 rounded-2xl p-8 text-white">
            {/* Animated Background Elements */}
            <div className="absolute inset-0">
              {Array.from({ length: 20 }).map((_, i) => (
                <motion.div
                  key={i}
                  className="absolute rounded-full bg-white/10"
                  style={{
                    width: Math.random() * 60 + 20,
                    height: Math.random() * 60 + 20,
                    left: `${Math.random() * 100}%`,
                    top: `${Math.random() * 100}%`,
                  }}
                  animate={{
                    x: [0, Math.random() * 50 - 25],
                    y: [0, Math.random() * 50 - 25],
                    scale: [1, 1.2, 1],
                    opacity: [0.1, 0.3, 0.1],
                  }}
                  transition={{
                    duration: Math.random() * 8 + 5,
                    repeat: Infinity,
                    ease: "easeInOut",
                  }}
                />
              ))}
            </div>

            <div className="relative z-10 flex flex-col md:flex-row justify-between items-start md:items-center">
              <div className="flex-1">
                <div className="flex items-center space-x-2 mb-2">
                  <Sparkles className="h-6 w-6" />
                  <span className="text-lg font-semibold">
                    Good {currentTime.getHours() < 12 ? 'Morning' : currentTime.getHours() < 18 ? 'Afternoon' : 'Evening'}, {user.name}! 
                  </span>
                </div>
                <h2 className="text-3xl font-bold mb-3">Ready to Learn Something Amazing? ✨</h2>
                <p className="text-blue-100 text-lg mb-4">
                  You have {assignments.filter(a => a.status === 'pending').length} pending assignments, 
                  {' '}{projects.filter(p => p.status === 'in-progress').length} active projects, and 
                  {' '}{upcomingEvents.length} upcoming events.
                </p>
                <div className="flex items-center space-x-4 text-sm">
                  <div className="flex items-center space-x-1">
                    <Trophy className="h-4 w-4" />
                    <span>Rank #{stats.rank}</span>
                  </div>
                  <div className="flex items-center space-x-1">
                    <Zap className="h-4 w-4" />
                    <span>{stats.currentStreak} day streak</span>
                  </div>
                  <div className="flex items-center space-x-1">
                    <Clock className="h-4 w-4" />
                    <span>{stats.studyHours}h studied</span>
                  </div>
                </div>
              </div>
              
              <div className="mt-6 md:mt-0 flex flex-col sm:flex-row space-y-2 sm:space-y-0 sm:space-x-3">
                <Button variant="secondary" size="sm" className="bg-white/20 hover:bg-white/30 border-white/30">
                  <Calendar className="h-4 w-4 mr-2" />
                  View Schedule
                </Button>
                <Button variant="outline" size="sm" className="border-white text-white hover:bg-white hover:text-blue-600">
                  <TrendingUp className="h-4 w-4 mr-2" />
                  Progress Report
                </Button>
              </div>
            </div>

            {/* 3D Element */}
            <div className="absolute right-4 top-4 w-24 h-24 opacity-30">
              <Scene3D type="books" className="w-full h-full" />
            </div>
          </div>
        </motion.div>

        {/* Enhanced Stats Grid */}
        <motion.div
          variants={containerVariants}
          initial="hidden"
          animate="visible"
          className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4 mb-8"
        >
          {[
            {
              title: 'Completion Rate',
              value: `${Math.round((stats.completedAssignments / stats.totalAssignments) * 100)}%`,
              icon: Target,
              color: 'from-green-500 to-emerald-500',
              change: '+5%',
              bgColor: isDarkMode ? 'bg-gray-800' : 'bg-white'
            },
            {
              title: 'Average Grade',
              value: `${stats.averageGrade}%`,
              icon: TrendingUp,
              color: 'from-blue-500 to-cyan-500',
              change: '+3%',
              bgColor: isDarkMode ? 'bg-gray-800' : 'bg-white'
            },
            {
              title: 'Study Streak',
              value: `${stats.currentStreak} days`,
              icon: Award,
              color: 'from-yellow-500 to-orange-500',
              change: 'Active',
              bgColor: isDarkMode ? 'bg-gray-800' : 'bg-white'
            },
            {
              title: 'Class Rank',
              value: `#${stats.rank}`,
              icon: Star,
              color: 'from-purple-500 to-pink-500',
              change: '+2',
              bgColor: isDarkMode ? 'bg-gray-800' : 'bg-white'
            },
            {
              title: 'Certificates',
              value: stats.certificatesEarned.toString(),
              icon: Medal,
              color: 'from-indigo-500 to-purple-500',
              change: '+1',
              bgColor: isDarkMode ? 'bg-gray-800' : 'bg-white'
            },
            {
              title: 'Attendance',
              value: `${stats.attendanceRate}%`,
              icon: CheckCircle,
              color: 'from-teal-500 to-green-500',
              change: '+2%',
              bgColor: isDarkMode ? 'bg-gray-800' : 'bg-white'
            }
          ].map((stat, index) => (
            <motion.div key={index} variants={itemVariants}>
              <Card className={`p-4 hover:shadow-lg transition-all duration-300 ${stat.bgColor} ${isDarkMode ? 'border-gray-700' : 'border-gray-200'}`}>
                <div className="flex items-center justify-between mb-2">
                  <div className={`w-10 h-10 bg-gradient-to-r ${stat.color} rounded-lg flex items-center justify-center`}>
                    <stat.icon className="h-5 w-5 text-white" />
                  </div>
                  <span className="text-xs text-green-600 font-medium">{stat.change}</span>
                </div>
                <p className={`text-xs font-medium ${isDarkMode ? 'text-gray-400' : 'text-gray-600'}`}>{stat.title}</p>
                <p className={`text-xl font-bold ${isDarkMode ? 'text-white' : 'text-gray-900'} mt-1`}>{stat.value}</p>
              </Card>
            </motion.div>
          ))}
        </motion.div>

        {/* Enhanced Navigation Tabs */}
        <div className="mb-6">
          <div className={`border-b ${isDarkMode ? 'border-gray-700' : 'border-gray-200'}`}>
            <nav className="flex space-x-8 overflow-x-auto scrollbar-hide">
              {tabItems.map((tab) => (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`flex items-center space-x-2 py-4 px-1 border-b-2 font-medium text-sm transition-colors whitespace-nowrap ${
                    activeTab === tab.id
                      ? 'border-blue-500 text-blue-600'
                      : isDarkMode 
                        ? 'border-transparent text-gray-400 hover:text-gray-300 hover:border-gray-600'
                        : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                  }`}
                >
                  <tab.icon className="h-4 w-4" />
                  <span>{tab.label}</span>
                </button>
              ))}
            </nav>
          </div>
        </div>

        {/* Enhanced Tab Content */}
        <AnimatePresence mode="wait">
          <motion.div
            key={activeTab}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            transition={{ duration: 0.3 }}
          >
            {activeTab === 'overview' && (
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                {/* Quick Actions */}
                <Card className={`p-6 ${isDarkMode ? 'bg-gray-800 border-gray-700' : 'bg-white border-gray-200'}`}>
                  <h3 className={`text-lg font-semibold mb-4 ${isDarkMode ? 'text-white' : 'text-gray-900'}`}>Quick Actions</h3>
                  <div className="space-y-3">
                    {[
                      { icon: FileText, label: 'View All Assignments', action: () => setActiveTab('assignments'), color: 'text-blue-600' },
                      { icon: Code, label: 'Start Coding Lab', action: () => setActiveTab('coding'), color: 'text-green-600' },
                      { icon: Brain, label: 'Take MCQ Test', action: () => setActiveTab('mcq'), color: 'text-purple-600' },
                      { icon: Microscope, label: 'Virtual Lab', action: () => setActiveTab('labs'), color: 'text-orange-600' },
                      { icon: Users, label: 'Join Study Group', action: () => setActiveTab('groups'), color: 'text-pink-600' },
                      { icon: Library, label: 'Browse Library', action: () => setActiveTab('library'), color: 'text-indigo-600' }
                    ].map((item, index) => (
                      <Button
                        key={index}
                        variant="outline"
                        className={`w-full justify-start ${isDarkMode ? 'border-gray-600 hover:bg-gray-700' : 'border-gray-300 hover:bg-gray-50'}`}
                        onClick={item.action}
                      >
                        <item.icon className={`h-4 w-4 mr-2 ${item.color}`} />
                        {item.label}
                      </Button>
                    ))}
                  </div>
                </Card>

                {/* Upcoming Deadlines */}
                <Card className={`p-6 ${isDarkMode ? 'bg-gray-800 border-gray-700' : 'bg-white border-gray-200'}`}>
                  <h3 className={`text-lg font-semibold mb-4 ${isDarkMode ? 'text-white' : 'text-gray-900'}`}>Upcoming Deadlines</h3>
                  <div className="space-y-3">
                    {assignments
                      .filter(a => a.status === 'pending')
                      .slice(0, 4)
                      .map((assignment) => (
                        <div key={assignment.id} className={`p-3 rounded-lg ${isDarkMode ? 'bg-gray-700' : 'bg-gray-50'}`}>
                          <div className="flex items-center justify-between">
                            <div className="flex-1">
                              <p className={`font-medium text-sm ${isDarkMode ? 'text-white' : 'text-gray-900'}`}>{assignment.title}</p>
                              <p className={`text-xs ${isDarkMode ? 'text-gray-400' : 'text-gray-500'}`}>{assignment.subject}</p>
                            </div>
                            <div className="text-right">
                              <p className={`text-sm font-medium ${isDarkMode ? 'text-white' : 'text-gray-900'}`}>
                                {new Date(assignment.dueDate).toLocaleDateString()}
                              </p>
                              <p className="text-xs text-red-600">Due soon</p>
                            </div>
                          </div>
                        </div>
                      ))}
                  </div>
                </Card>

                {/* Recent Activity */}
                <Card className={`p-6 ${isDarkMode ? 'bg-gray-800 border-gray-700' : 'bg-white border-gray-200'}`}>
                  <h3 className={`text-lg font-semibold mb-4 ${isDarkMode ? 'text-white' : 'text-gray-900'}`}>Recent Activity</h3>
                  <div className="space-y-3">
                    {[
                      { icon: CheckCircle, text: 'Completed Database Assignment', time: '2 hours ago', color: 'text-green-600' },
                      { icon: Brain, text: 'AI feedback received', time: '5 hours ago', color: 'text-blue-600' },
                      { icon: Award, text: 'Earned "Quick Learner" badge', time: '1 day ago', color: 'text-yellow-600' },
                      { icon: Users, text: 'Joined AI Study Group', time: '2 days ago', color: 'text-purple-600' }
                    ].map((activity, index) => (
                      <div key={index} className="flex items-start space-x-3">
                        <div className={`w-8 h-8 rounded-full flex items-center justify-center ${activity.color} bg-opacity-10`}>
                          <activity.icon className={`h-4 w-4 ${activity.color}`} />
                        </div>
                        <div className="flex-1">
                          <p className={`text-sm font-medium ${isDarkMode ? 'text-white' : 'text-gray-900'}`}>{activity.text}</p>
                          <p className={`text-xs ${isDarkMode ? 'text-gray-400' : 'text-gray-500'}`}>{activity.time}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </Card>
              </div>
            )}

            {activeTab === 'assignments' && (
              <div>
                <div className="flex justify-between items-center mb-6">
                  <h2 className={`text-xl font-semibold ${isDarkMode ? 'text-white' : 'text-gray-900'}`}>Assignments</h2>
                  <div className="flex items-center space-x-3">
                    <select
                      value={filterStatus}
                      onChange={(e) => setFilterStatus(e.target.value)}
                      className={`px-3 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 ${
                        isDarkMode ? 'bg-gray-700 border-gray-600 text-white' : 'bg-white border-gray-300 text-gray-900'
                      }`}
                    >
                      <option value="all">All Status</option>
                      <option value="pending">Pending</option>
                      <option value="completed">Completed</option>
                      <option value="overdue">Overdue</option>
                    </select>
                    <Button size="sm">
                      <Filter className="h-4 w-4 mr-2" />
                      Filter
                    </Button>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {filteredAssignments.map((assignment) => (
                    <motion.div
                      key={assignment.id}
                      whileHover={{ y: -4 }}
                      transition={{ duration: 0.2 }}
                    >
                      <Card className={`p-6 cursor-pointer hover:shadow-lg transition-all duration-300 ${isDarkMode ? 'bg-gray-800 border-gray-700' : 'bg-white border-gray-200'}`}>
                        <div className="flex justify-between items-start mb-4">
                          <h3 className={`font-semibold ${isDarkMode ? 'text-white' : 'text-gray-900'}`}>{assignment.title}</h3>
                          <span className={`px-2 py-1 text-xs rounded-full border ${getStatusColor(assignment.status)}`}>
                            {assignment.status}
                          </span>
                        </div>
                        <p className={`text-sm mb-3 ${isDarkMode ? 'text-gray-400' : 'text-gray-600'}`}>{assignment.subject}</p>
                        {assignment.description && (
                          <p className={`text-sm mb-4 line-clamp-2 ${isDarkMode ? 'text-gray-300' : 'text-gray-500'}`}>{assignment.description}</p>
                        )}
                        <div className="flex justify-between items-center mb-4">
                          <div className={`text-sm ${isDarkMode ? 'text-gray-400' : 'text-gray-500'}`}>
                            Due: {new Date(assignment.dueDate).toLocaleDateString()}
                          </div>
                          {assignment.grade && (
                            <div className="text-sm font-medium text-green-600">
                              Grade: {assignment.grade}/{assignment.maxGrade}
                            </div>
                          )}
                        </div>
                        <div className="flex space-x-2">
                          <Button
                            size="sm"
                            className="flex-1"
                            onClick={() => navigate(`/student/assignment/${assignment.id}`)}
                          >
                            {assignment.status === 'completed' ? 'View Details' : 'Start Assignment'}
                          </Button>
                          <Button variant="outline" size="sm">
                            <MoreVertical className="h-4 w-4" />
                          </Button>
                        </div>
                      </Card>
                    </motion.div>
                  ))}
                </div>
              </div>
            )}

            {activeTab === 'materials' && (
              <div>
                <div className="flex justify-between items-center mb-6">
                  <h2 className={`text-xl font-semibold ${isDarkMode ? 'text-white' : 'text-gray-900'}`}>Study Materials</h2>
                  <Button>
                    <Plus className="h-4 w-4 mr-2" />
                    Upload Material
                  </Button>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {studyMaterials.map((material) => (
                    <motion.div
                      key={material.id}
                      whileHover={{ y: -4 }}
                      transition={{ duration: 0.2 }}
                    >
                      <Card className={`p-6 cursor-pointer hover:shadow-lg transition-all duration-300 ${isDarkMode ? 'bg-gray-800 border-gray-700' : 'bg-white border-gray-200'}`}>
                        <div className="flex items-start justify-between mb-4">
                          <div className="flex items-center space-x-3">
                            <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${
                              material.type === 'video' ? 'bg-red-100 text-red-600' :
                              material.type === 'pdf' ? 'bg-blue-100 text-blue-600' :
                              'bg-green-100 text-green-600'
                            }`}>
                              {material.type === 'video' ? <Video className="h-5 w-5" /> :
                               material.type === 'pdf' ? <FileText className="h-5 w-5" /> :
                               <Globe className="h-5 w-5" />}
                            </div>
                            <div>
                              <h3 className={`font-semibold ${isDarkMode ? 'text-white' : 'text-gray-900'}`}>{material.title}</h3>
                              <p className={`text-sm ${isDarkMode ? 'text-gray-400' : 'text-gray-600'}`}>{material.subject}</p>
                            </div>
                          </div>
                          <Button variant="ghost" size="sm">
                            <MoreVertical className="h-4 w-4" />
                          </Button>
                        </div>
                        
                        <p className={`text-sm mb-4 line-clamp-2 ${isDarkMode ? 'text-gray-300' : 'text-gray-500'}`}>
                          {material.description}
                        </p>
                        
                        <div className="flex flex-wrap gap-1 mb-4">
                          {material.tags.map((tag, index) => (
                            <span key={index} className="px-2 py-1 bg-blue-100 text-blue-800 text-xs rounded-full">
                              {tag}
                            </span>
                          ))}
                        </div>
                        
                        <div className="flex justify-between items-center mb-4">
                          <div className={`text-sm ${isDarkMode ? 'text-gray-400' : 'text-gray-500'}`}>
                            {material.duration || material.size}
                          </div>
                          <div className={`text-sm ${isDarkMode ? 'text-gray-400' : 'text-gray-500'}`}>
                            {new Date(material.uploadDate).toLocaleDateString()}
                          </div>
                        </div>
                        
                        <div className="flex space-x-2">
                          <Button size="sm" className="flex-1">
                            <Eye className="h-4 w-4 mr-2" />
                            View
                          </Button>
                          <Button variant="outline" size="sm">
                            <Download className="h-4 w-4" />
                          </Button>
                          <Button variant="outline" size="sm">
                            <Share className="h-4 w-4" />
                          </Button>
                        </div>
                      </Card>
                    </motion.div>
                  ))}
                </div>
              </div>
            )}

            {activeTab === 'labs' && (
              <div>
                <div className="flex justify-between items-center mb-6">
                  <h2 className={`text-xl font-semibold ${isDarkMode ? 'text-white' : 'text-gray-900'}`}>Virtual Labs</h2>
                  <Button>
                    <Microscope className="h-4 w-4 mr-2" />
                    Create Lab
                  </Button>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {virtualLabs.map((lab) => (
                    <motion.div
                      key={lab.id}
                      whileHover={{ y: -4 }}
                      transition={{ duration: 0.2 }}
                    >
                      <Card className={`p-6 cursor-pointer hover:shadow-lg transition-all duration-300 ${isDarkMode ? 'bg-gray-800 border-gray-700' : 'bg-white border-gray-200'}`}>
                        <div className="flex justify-between items-start mb-4">
                          <h3 className={`font-semibold ${isDarkMode ? 'text-white' : 'text-gray-900'}`}>{lab.title}</h3>
                          <span className={`px-2 py-1 text-xs rounded-full ${getDifficultyColor(lab.difficulty)}`}>
                            {lab.difficulty}
                          </span>
                        </div>
                        
                        <p className={`text-sm mb-3 ${isDarkMode ? 'text-gray-400' : 'text-gray-600'}`}>{lab.subject}</p>
                        <p className={`text-sm mb-4 line-clamp-2 ${isDarkMode ? 'text-gray-300' : 'text-gray-500'}`}>{lab.description}</p>
                        
                        <div className="space-y-2 mb-4">
                          <div className="flex justify-between text-sm">
                            <span className={isDarkMode ? 'text-gray-400' : 'text-gray-500'}>Duration:</span>
                            <span className={isDarkMode ? 'text-white' : 'text-gray-900'}>{lab.estimatedTime} min</span>
                          </div>
                          <div className="flex justify-between text-sm">
                            <span className={isDarkMode ? 'text-gray-400' : 'text-gray-500'}>Type:</span>
                            <span className={isDarkMode ? 'text-white' : 'text-gray-900'}>{lab.type}</span>
                          </div>
                        </div>
                        
                        <Button
                          size="sm"
                          className="w-full"
                          onClick={() => navigate(`/student/lab/${lab.id}`)}
                        >
                          <Play className="h-4 w-4 mr-2" />
                          Start Lab
                        </Button>
                      </Card>
                    </motion.div>
                  ))}
                </div>
              </div>
            )}

            {activeTab === 'discussions' && (
              <div>
                <div className="flex justify-between items-center mb-6">
                  <h2 className={`text-xl font-semibold ${isDarkMode ? 'text-white' : 'text-gray-900'}`}>Discussions</h2>
                  <Button>
                    <Plus className="h-4 w-4 mr-2" />
                    New Discussion
                  </Button>
                </div>

                <div className="space-y-4">
                  {discussions.map((discussion) => (
                    <Card key={discussion.id} className={`p-6 ${isDarkMode ? 'bg-gray-800 border-gray-700' : 'bg-white border-gray-200'}`}>
                      <div className="flex items-start justify-between mb-4">
                        <div className="flex-1">
                          <h3 className={`font-semibold mb-2 ${isDarkMode ? 'text-white' : 'text-gray-900'}`}>{discussion.title}</h3>
                          <p className={`text-sm mb-3 ${isDarkMode ? 'text-gray-300' : 'text-gray-600'}`}>{discussion.content}</p>
                          <div className="flex items-center space-x-4 text-sm">
                            <span className={isDarkMode ? 'text-gray-400' : 'text-gray-500'}>by {discussion.author}</span>
                            <span className={isDarkMode ? 'text-gray-400' : 'text-gray-500'}>{discussion.subject}</span>
                            <span className={isDarkMode ? 'text-gray-400' : 'text-gray-500'}>
                              {new Date(discussion.createdAt).toLocaleDateString()}
                            </span>
                          </div>
                        </div>
                        <Button variant="ghost" size="sm">
                          <MoreVertical className="h-4 w-4" />
                        </Button>
                      </div>
                      
                      <div className="flex flex-wrap gap-1 mb-4">
                        {discussion.tags.map((tag, index) => (
                          <span key={index} className="px-2 py-1 bg-purple-100 text-purple-800 text-xs rounded-full">
                            {tag}
                          </span>
                        ))}
                      </div>
                      
                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-4">
                          <button className="flex items-center space-x-1 text-sm text-gray-500 hover:text-blue-600">
                            <ThumbsUp className="h-4 w-4" />
                            <span>{discussion.likes}</span>
                          </button>
                          <button className="flex items-center space-x-1 text-sm text-gray-500 hover:text-blue-600">
                            <MessageSquare className="h-4 w-4" />
                            <span>{discussion.replies.length}</span>
                          </button>
                          <span className="text-sm text-gray-500">{discussion.views} views</span>
                        </div>
                        <Button size="sm" variant="outline">
                          Reply
                        </Button>
                      </div>
                    </Card>
                  ))}
                </div>
              </div>
            )}

            {activeTab === 'groups' && (
              <div>
                <div className="flex justify-between items-center mb-6">
                  <h2 className={`text-xl font-semibold ${isDarkMode ? 'text-white' : 'text-gray-900'}`}>Study Groups</h2>
                  <Button>
                    <Plus className="h-4 w-4 mr-2" />
                    Create Group
                  </Button>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {studyGroups.map((group) => (
                    <motion.div
                      key={group.id}
                      whileHover={{ y: -4 }}
                      transition={{ duration: 0.2 }}
                    >
                      <Card className={`p-6 cursor-pointer hover:shadow-lg transition-all duration-300 ${isDarkMode ? 'bg-gray-800 border-gray-700' : 'bg-white border-gray-200'}`}>
                        <div className="flex items-center justify-between mb-4">
                          <h3 className={`font-semibold ${isDarkMode ? 'text-white' : 'text-gray-900'}`}>{group.name}</h3>
                          <div className="flex -space-x-2">
                            {group.members.slice(0, 3).map((member, index) => (
                              <div key={index} className="w-8 h-8 bg-gradient-to-r from-blue-500 to-purple-500 rounded-full flex items-center justify-center border-2 border-white text-white text-xs font-medium">
                                {member.charAt(0)}
                              </div>
                            ))}
                            {group.members.length > 3 && (
                              <div className="w-8 h-8 bg-gray-300 rounded-full flex items-center justify-center border-2 border-white text-gray-600 text-xs font-medium">
                                +{group.members.length - 3}
                              </div>
                            )}
                          </div>
                        </div>
                        
                        <p className={`text-sm mb-3 ${isDarkMode ? 'text-gray-400' : 'text-gray-600'}`}>{group.subject}</p>
                        <p className={`text-sm mb-4 line-clamp-2 ${isDarkMode ? 'text-gray-300' : 'text-gray-500'}`}>{group.description}</p>
                        
                        <div className="flex justify-between items-center mb-4">
                          <span className={`text-sm ${isDarkMode ? 'text-gray-400' : 'text-gray-500'}`}>
                            {group.members.length} members
                          </span>
                          {group.nextMeeting && (
                            <span className="text-sm text-blue-600">
                              Next: {new Date(group.nextMeeting).toLocaleDateString()}
                            </span>
                          )}
                        </div>
                        
                        <Button size="sm" className="w-full">
                          <Users className="h-4 w-4 mr-2" />
                          Join Group
                        </Button>
                      </Card>
                    </motion.div>
                  ))}
                </div>
              </div>
            )}

            {activeTab === 'projects' && (
              <div>
                <div className="flex justify-between items-center mb-6">
                  <h2 className={`text-xl font-semibold ${isDarkMode ? 'text-white' : 'text-gray-900'}`}>Projects</h2>
                  <Button>
                    <Plus className="h-4 w-4 mr-2" />
                    New Project
                  </Button>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {projects.map((project) => (
                    <motion.div
                      key={project.id}
                      whileHover={{ y: -4 }}
                      transition={{ duration: 0.2 }}
                    >
                      <Card className={`p-6 cursor-pointer hover:shadow-lg transition-all duration-300 ${isDarkMode ? 'bg-gray-800 border-gray-700' : 'bg-white border-gray-200'}`}>
                        <div className="flex justify-between items-start mb-4">
                          <h3 className={`font-semibold ${isDarkMode ? 'text-white' : 'text-gray-900'}`}>{project.title}</h3>
                          <span className={`px-2 py-1 text-xs rounded-full border ${getStatusColor(project.status)}`}>
                            {project.status}
                          </span>
                        </div>
                        
                        <p className={`text-sm mb-3 ${isDarkMode ? 'text-gray-400' : 'text-gray-600'}`}>{project.subject}</p>
                        <p className={`text-sm mb-4 line-clamp-2 ${isDarkMode ? 'text-gray-300' : 'text-gray-500'}`}>{project.description}</p>
                        
                        <div className="mb-4">
                          <div className="flex justify-between text-sm mb-1">
                            <span className={isDarkMode ? 'text-gray-400' : 'text-gray-500'}>Progress</span>
                            <span className={isDarkMode ? 'text-white' : 'text-gray-900'}>{project.progress}%</span>
                          </div>
                          <div className="w-full bg-gray-200 rounded-full h-2">
                            <div 
                              className="bg-blue-600 h-2 rounded-full transition-all duration-300" 
                              style={{ width: `${project.progress}%` }}
                            ></div>
                          </div>
                        </div>
                        
                        <div className="flex justify-between items-center mb-4">
                          <div className="flex -space-x-2">
                            {project.teamMembers.slice(0, 3).map((member, index) => (
                              <div key={index} className="w-6 h-6 bg-gradient-to-r from-green-500 to-blue-500 rounded-full flex items-center justify-center border-2 border-white text-white text-xs font-medium">
                                {member.charAt(0)}
                              </div>
                            ))}
                          </div>
                          <span className={`text-sm ${isDarkMode ? 'text-gray-400' : 'text-gray-500'}`}>
                            Due: {new Date(project.dueDate).toLocaleDateString()}
                          </span>
                        </div>
                        
                        <Button size="sm" className="w-full">
                          <Briefcase className="h-4 w-4 mr-2" />
                          View Project
                        </Button>
                      </Card>
                    </motion.div>
                  ))}
                </div>
              </div>
            )}

            {activeTab === 'notes' && (
              <div>
                <div className="flex justify-between items-center mb-6">
                  <h2 className={`text-xl font-semibold ${isDarkMode ? 'text-white' : 'text-gray-900'}`}>My Notes</h2>
                  <Button>
                    <Plus className="h-4 w-4 mr-2" />
                    New Note
                  </Button>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {notes.map((note) => (
                    <motion.div
                      key={note.id}
                      whileHover={{ y: -4 }}
                      transition={{ duration: 0.2 }}
                    >
                      <Card className={`p-6 cursor-pointer hover:shadow-lg transition-all duration-300 ${isDarkMode ? 'bg-gray-800 border-gray-700' : 'bg-white border-gray-200'}`}>
                        <div className="flex justify-between items-start mb-4">
                          <h3 className={`font-semibold ${isDarkMode ? 'text-white' : 'text-gray-900'}`}>{note.title}</h3>
                          <Button variant="ghost" size="sm">
                            <MoreVertical className="h-4 w-4" />
                          </Button>
                        </div>
                        
                        <p className={`text-sm mb-3 ${isDarkMode ? 'text-gray-400' : 'text-gray-600'}`}>{note.subject}</p>
                        <p className={`text-sm mb-4 line-clamp-3 ${isDarkMode ? 'text-gray-300' : 'text-gray-500'}`}>{note.content}</p>
                        
                        <div className="flex flex-wrap gap-1 mb-4">
                          {note.tags.map((tag, index) => (
                            <span key={index} className="px-2 py-1 bg-green-100 text-green-800 text-xs rounded-full">
                              {tag}
                            </span>
                          ))}
                        </div>
                        
                        <div className="flex justify-between items-center">
                          <span className={`text-sm ${isDarkMode ? 'text-gray-400' : 'text-gray-500'}`}>
                            {new Date(note.updatedAt).toLocaleDateString()}
                          </span>
                          <div className="flex space-x-2">
                            <Button size="sm" variant="outline">
                              <Eye className="h-4 w-4" />
                            </Button>
                            <Button size="sm" variant="outline">
                              <Share className="h-4 w-4" />
                            </Button>
                          </div>
                        </div>
                      </Card>
                    </motion.div>
                  ))}
                </div>
              </div>
            )}

            {activeTab === 'library' && (
              <div>
                <div className="flex justify-between items-center mb-6">
                  <h2 className={`text-xl font-semibold ${isDarkMode ? 'text-white' : 'text-gray-900'}`}>Digital Library</h2>
                  <Button>
                    <Search className="h-4 w-4 mr-2" />
                    Advanced Search
                  </Button>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {libraryBooks.map((book) => (
                    <motion.div
                      key={book.id}
                      whileHover={{ y: -4 }}
                      transition={{ duration: 0.2 }}
                    >
                      <Card className={`p-6 cursor-pointer hover:shadow-lg transition-all duration-300 ${isDarkMode ? 'bg-gray-800 border-gray-700' : 'bg-white border-gray-200'}`}>
                        <div className="flex items-start space-x-4 mb-4">
                          <div className="w-16 h-20 bg-gradient-to-br from-blue-500 to-purple-500 rounded-lg flex items-center justify-center">
                            <BookOpen className="h-8 w-8 text-white" />
                          </div>
                          <div className="flex-1">
                            <h3 className={`font-semibold mb-1 ${isDarkMode ? 'text-white' : 'text-gray-900'}`}>{book.title}</h3>
                            <p className={`text-sm mb-1 ${isDarkMode ? 'text-gray-400' : 'text-gray-600'}`}>{book.author}</p>
                            <p className={`text-sm ${isDarkMode ? 'text-gray-400' : 'text-gray-600'}`}>{book.subject}</p>
                          </div>
                        </div>
                        
                        <p className={`text-sm mb-4 line-clamp-2 ${isDarkMode ? 'text-gray-300' : 'text-gray-500'}`}>{book.description}</p>
                        
                        <div className="flex justify-between items-center mb-4">
                          <span className={`text-sm ${isDarkMode ? 'text-gray-400' : 'text-gray-500'}`}>
                            Available: {book.availableCopies}/{book.totalCopies}
                          </span>
                          <span className={`px-2 py-1 text-xs rounded-full ${
                            book.status === 'available' ? 'bg-green-100 text-green-800' :
                            book.status === 'borrowed' ? 'bg-yellow-100 text-yellow-800' :
                            'bg-red-100 text-red-800'
                          }`}>
                            {book.status}
                          </span>
                        </div>
                        
                        <Button 
                          size="sm" 
                          className="w-full" 
                          disabled={book.status !== 'available'}
                        >
                          <BookOpen className="h-4 w-4 mr-2" />
                          {book.status === 'available' ? 'Borrow Book' : 'Not Available'}
                        </Button>
                      </Card>
                    </motion.div>
                  ))}
                </div>
              </div>
            )}

            {activeTab === 'certificates' && (
              <div>
                <div className="flex justify-between items-center mb-6">
                  <h2 className={`text-xl font-semibold ${isDarkMode ? 'text-white' : 'text-gray-900'}`}>My Certificates</h2>
                  <Button>
                    <Award className="h-4 w-4 mr-2" />
                    Browse Courses
                  </Button>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {certificates.map((certificate) => (
                    <motion.div
                      key={certificate.id}
                      whileHover={{ y: -4 }}
                      transition={{ duration: 0.2 }}
                    >
                      <Card className={`p-6 cursor-pointer hover:shadow-lg transition-all duration-300 bg-gradient-to-br from-yellow-50 to-orange-50 border-yellow-200 ${isDarkMode ? 'from-yellow-900/20 to-orange-900/20 border-yellow-700' : ''}`}>
                        <div className="text-center mb-4">
                          <div className="w-16 h-16 bg-gradient-to-r from-yellow-500 to-orange-500 rounded-full flex items-center justify-center mx-auto mb-3">
                            <Award className="h-8 w-8 text-white" />
                          </div>
                          <h3 className={`font-semibold ${isDarkMode ? 'text-white' : 'text-gray-900'}`}>{certificate.title}</h3>
                        </div>
                        
                        <p className={`text-sm mb-4 text-center ${isDarkMode ? 'text-gray-300' : 'text-gray-600'}`}>{certificate.description}</p>
                        
                        <div className="flex flex-wrap gap-1 mb-4 justify-center">
                          {certificate.skills.map((skill, index) => (
                            <span key={index} className="px-2 py-1 bg-yellow-100 text-yellow-800 text-xs rounded-full">
                              {skill}
                            </span>
                          ))}
                        </div>
                        
                        <div className="text-center mb-4">
                          <p className={`text-sm ${isDarkMode ? 'text-gray-400' : 'text-gray-500'}`}>
                            Issued: {new Date(certificate.issuedDate).toLocaleDateString()}
                          </p>
                          <p className={`text-xs ${isDarkMode ? 'text-gray-400' : 'text-gray-500'}`}>
                            ID: {certificate.credentialId}
                          </p>
                        </div>
                        
                        <div className="flex space-x-2">
                          <Button size="sm" className="flex-1">
                            <Eye className="h-4 w-4 mr-2" />
                            View
                          </Button>
                          <Button size="sm" variant="outline">
                            <Download className="h-4 w-4" />
                          </Button>
                          <Button size="sm" variant="outline">
                            <Share className="h-4 w-4" />
                          </Button>
                        </div>
                      </Card>
                    </motion.div>
                  ))}
                </div>
              </div>
            )}
          </motion.div>
        </AnimatePresence>
      </div>
    </div>
  );
};
