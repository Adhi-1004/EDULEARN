import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useNavigate } from 'react-router-dom';
import { BookOpen, Users, FileText, TrendingUp, Award, Clock, Target, Brain, Calendar, Bell, Search, Filter, MoreVertical, Eye, MessageSquare, CheckCircle, AlertTriangle, Star, BarChart3, PieChart, Activity } from 'lucide-react';
import { Card } from '../../components/ui/Card';
import { Button } from '../../components/ui/Button';
import { User, StudentProgress } from '../../types';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, BarChart, Bar, PieChart as RechartsPieChart, Cell } from 'recharts';

interface TeacherDashboardProps {
  user: User;
  onLogout: () => void;
}

export const TeacherDashboard: React.FC<TeacherDashboardProps> = ({ user, onLogout }) => {
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState('overview');
  const [selectedSection, setSelectedSection] = useState('Section A');
  const [searchQuery, setSearchQuery] = useState('');

  // Mock data
  const [sections] = useState(['Section A', 'Section B', 'Section C', 'Section D']);
  
  const [studentsProgress] = useState<StudentProgress[]>([
    {
      studentId: '1',
      studentName: 'John Smith',
      averageGrade: 92,
      completedAssignments: 8,
      totalAssignments: 10,
      weakAreas: ['Algorithm Complexity', 'Recursion'],
      strengths: ['Data Structures', 'Problem Solving'],
      lastActivity: '2 hours ago'
    },
    {
      studentId: '2',
      studentName: 'Emily Johnson',
      averageGrade: 88,
      completedAssignments: 9,
      totalAssignments: 10,
      weakAreas: ['Database Design', 'SQL Optimization'],
      strengths: ['Web Development', 'JavaScript'],
      lastActivity: '5 hours ago'
    },
    {
      studentId: '3',
      studentName: 'Michael Brown',
      averageGrade: 85,
      completedAssignments: 7,
      totalAssignments: 10,
      weakAreas: ['Machine Learning', 'Statistics'],
      strengths: ['Python Programming', 'Data Analysis'],
      lastActivity: '1 day ago'
    }
  ]);

  const [classStats] = useState({
    totalStudents: 120,
    activeStudents: 98,
    averageGrade: 84,
    completionRate: 87,
    pendingReviews: 15,
    totalAssignments: 45
  });

  const [performanceData] = useState([
    { month: 'Jan', average: 78, section: 82 },
    { month: 'Feb', average: 82, section: 85 },
    { month: 'Mar', average: 79, section: 83 },
    { month: 'Apr', average: 85, section: 88 },
    { month: 'May', average: 84, section: 87 },
    { month: 'Jun', average: 87, section: 90 }
  ]);

  const [gradeDistribution] = useState([
    { grade: 'A', count: 35, color: '#10B981' },
    { grade: 'B', count: 45, color: '#3B82F6' },
    { grade: 'C', count: 25, color: '#F59E0B' },
    { grade: 'D', count: 10, color: '#EF4444' },
    { grade: 'F', count: 5, color: '#6B7280' }
  ]);

  const [recentSubmissions] = useState([
    {
      id: '1',
      studentName: 'John Smith',
      assignment: 'Data Structures Essay',
      submittedAt: '2 hours ago',
      status: 'pending',
      aiGraded: true
    },
    {
      id: '2',
      studentName: 'Emily Johnson',
      assignment: 'Algorithm Analysis',
      submittedAt: '4 hours ago',
      status: 'reviewed',
      aiGraded: true
    },
    {
      id: '3',
      studentName: 'Michael Brown',
      assignment: 'Database Project',
      submittedAt: '1 day ago',
      status: 'pending',
      aiGraded: false
    }
  ]);

  const [upcomingDeadlines] = useState([
    {
      id: '1',
      title: 'Machine Learning Project',
      dueDate: '2024-01-25',
      submissions: 45,
      totalStudents: 60
    },
    {
      id: '2',
      title: 'Database Design Assignment',
      dueDate: '2024-01-28',
      submissions: 12,
      totalStudents: 60
    }
  ]);

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'reviewed':
        return 'bg-green-100 text-green-800';
      case 'pending':
        return 'bg-yellow-100 text-yellow-800';
      case 'overdue':
        return 'bg-red-100 text-red-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const getGradeColor = (grade: number) => {
    if (grade >= 90) return 'text-green-600';
    if (grade >= 80) return 'text-blue-600';
    if (grade >= 70) return 'text-yellow-600';
    return 'text-red-600';
  };

  const filteredStudents = studentsProgress.filter(student =>
    student.studentName.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1
      }
    }
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: { duration: 0.5 }
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-2">
                <div className="w-8 h-8 bg-gradient-to-r from-blue-600 to-purple-600 rounded-lg flex items-center justify-center">
                  <BookOpen className="h-5 w-5 text-white" />
                </div>
                <span className="text-xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
                  EduLearn AI
                </span>
              </div>
              <div className="hidden md:block h-6 w-px bg-gray-300" />
              <h1 className="hidden md:block text-lg font-semibold text-gray-900">Teacher Dashboard</h1>
            </div>

            <div className="flex items-center space-x-4">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                <input
                  type="text"
                  placeholder="Search students..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 w-64"
                />
              </div>

              <button className="relative p-2 text-gray-600 hover:text-blue-600 transition-colors">
                <Bell className="h-6 w-6" />
                <span className="absolute top-0 right-0 h-2 w-2 bg-red-500 rounded-full"></span>
              </button>

              <div className="flex items-center space-x-3">
                <div className="w-8 h-8 bg-purple-100 rounded-full flex items-center justify-center">
                  <span className="text-purple-600 font-medium text-sm">
                    {user.name.split(' ').map(n => n[0]).join('')}
                  </span>
                </div>
                <div className="hidden md:block">
                  <p className="text-sm font-medium text-gray-900">{user.name}</p>
                  <p className="text-xs text-gray-500">Teacher</p>
                </div>
              </div>

              <Button variant="ghost" onClick={onLogout}>
                Logout
              </Button>
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Welcome Section */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8"
        >
          <div className="bg-gradient-to-r from-purple-600 to-blue-600 rounded-xl p-6 text-white">
            <div className="flex flex-col md:flex-row justify-between items-start md:items-center">
              <div>
                <h2 className="text-2xl font-bold mb-2">Welcome back, {user.name}! 👨‍🏫</h2>
                <p className="text-purple-100">
                  You have {classStats.pendingReviews} assignments to review and {classStats.activeStudents} active students across all sections.
                </p>
              </div>
              <div className="mt-4 md:mt-0 flex space-x-3">
                <Button variant="secondary" size="sm">
                  <Calendar className="h-4 w-4 mr-2" />
                  Schedule
                </Button>
                <Button variant="outline" size="sm" className="border-white text-white hover:bg-white hover:text-purple-600">
                  <BarChart3 className="h-4 w-4 mr-2" />
                  Analytics
                </Button>
              </div>
            </div>
          </div>
        </motion.div>

        {/* Section Selector */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-6"
        >
          <Card className="p-4">
            <div className="flex items-center justify-between">
              <h3 className="text-lg font-semibold text-gray-900">Class Sections</h3>
              <div className="flex space-x-2">
                {sections.map((section) => (
                  <button
                    key={section}
                    onClick={() => setSelectedSection(section)}
                    className={`px-4 py-2 rounded-lg font-medium text-sm transition-colors ${
                      selectedSection === section
                        ? 'bg-blue-600 text-white'
                        : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                    }`}
                  >
                    {section}
                  </button>
                ))}
              </div>
            </div>
          </Card>
        </motion.div>

        {/* Stats Grid */}
        <motion.div
          variants={containerVariants}
          initial="hidden"
          animate="visible"
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8"
        >
          {[
            {
              title: 'Total Students',
              value: classStats.totalStudents.toString(),
              icon: Users,
              color: 'from-blue-500 to-cyan-500',
              change: '+5 this month'
            },
            {
              title: 'Average Grade',
              value: `${classStats.averageGrade}%`,
              icon: TrendingUp,
              color: 'from-green-500 to-emerald-500',
              change: '+3% from last month'
            },
            {
              title: 'Completion Rate',
              value: `${classStats.completionRate}%`,
              icon: Target,
              color: 'from-purple-500 to-pink-500',
              change: '+2% improvement'
            },
            {
              title: 'Pending Reviews',
              value: classStats.pendingReviews.toString(),
              icon: Clock,
              color: 'from-orange-500 to-red-500',
              change: '5 urgent'
            }
          ].map((stat, index) => (
            <motion.div key={index} variants={itemVariants}>
              <Card className="p-6 hover:shadow-lg transition-all duration-300">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-gray-600">{stat.title}</p>
                    <p className="text-2xl font-bold text-gray-900 mt-1">{stat.value}</p>
                    <p className="text-sm text-green-600 mt-1">{stat.change}</p>
                  </div>
                  <div className={`w-12 h-12 bg-gradient-to-r ${stat.color} rounded-lg flex items-center justify-center`}>
                    <stat.icon className="h-6 w-6 text-white" />
                  </div>
                </div>
              </Card>
            </motion.div>
          ))}
        </motion.div>

        {/* Navigation Tabs */}
        <div className="mb-6">
          <nav className="flex space-x-8 border-b border-gray-200">
            {[
              { id: 'overview', label: 'Overview', icon: BarChart3 },
              { id: 'students', label: 'Student Progress', icon: Users },
              { id: 'assignments', label: 'Assignments', icon: FileText },
              { id: 'analytics', label: 'Analytics', icon: PieChart },
              { id: 'submissions', label: 'Recent Submissions', icon: Clock }
            ].map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`flex items-center space-x-2 py-4 px-1 border-b-2 font-medium text-sm transition-colors ${
                  activeTab === tab.id
                    ? 'border-blue-500 text-blue-600'
                    : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                }`}
              >
                <tab.icon className="h-4 w-4" />
                <span>{tab.label}</span>
              </button>
            ))}
          </nav>
        </div>

        {/* Tab Content */}
        <AnimatePresence mode="wait">
          <motion.div
            key={activeTab}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            transition={{ duration: 0.3 }}
          >
            {activeTab === 'overview' && (
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                {/* Performance Chart */}
                <Card className="p-6">
                  <h3 className="text-lg font-semibold text-gray-900 mb-4">Class Performance Trend</h3>
                  <ResponsiveContainer width="100%" height={300}>
                    <LineChart data={performanceData}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="month" />
                      <YAxis />
                      <Tooltip />
                      <Line type="monotone" dataKey="average" stroke="#8884d8" strokeWidth={2} />
                      <Line type="monotone" dataKey="section" stroke="#82ca9d" strokeWidth={2} />
                    </LineChart>
                  </ResponsiveContainer>
                </Card>

                {/* Grade Distribution */}
                <Card className="p-6">
                  <h3 className="text-lg font-semibold text-gray-900 mb-4">Grade Distribution</h3>
                  <ResponsiveContainer width="100%" height={300}>
                    <BarChart data={gradeDistribution}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="grade" />
                      <YAxis />
                      <Tooltip />
                      <Bar dataKey="count" fill="#8884d8" />
                    </BarChart>
                  </ResponsiveContainer>
                </Card>

                {/* Upcoming Deadlines */}
                <Card className="p-6">
                  <h3 className="text-lg font-semibold text-gray-900 mb-4">Upcoming Deadlines</h3>
                  <div className="space-y-4">
                    {upcomingDeadlines.map((deadline) => (
                      <div key={deadline.id} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                        <div>
                          <p className="font-medium text-gray-900">{deadline.title}</p>
                          <p className="text-sm text-gray-500">Due: {new Date(deadline.dueDate).toLocaleDateString()}</p>
                        </div>
                        <div className="text-right">
                          <p className="text-sm font-medium text-gray-900">
                            {deadline.submissions}/{deadline.totalStudents}
                          </p>
                          <p className="text-xs text-gray-500">submissions</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </Card>

                {/* Quick Actions */}
                <Card className="p-6">
                  <h3 className="text-lg font-semibold text-gray-900 mb-4">Quick Actions</h3>
                  <div className="space-y-3">
                    <Button variant="outline" className="w-full justify-start">
                      <FileText className="h-4 w-4 mr-2" />
                      Create New Assignment
                    </Button>
                    <Button variant="outline" className="w-full justify-start">
                      <Users className="h-4 w-4 mr-2" />
                      View All Students
                    </Button>
                    <Button variant="outline" className="w-full justify-start">
                      <BarChart3 className="h-4 w-4 mr-2" />
                      Generate Report
                    </Button>
                    <Button variant="outline" className="w-full justify-start">
                      <MessageSquare className="h-4 w-4 mr-2" />
                      Send Announcement
                    </Button>
                  </div>
                </Card>
              </div>
            )}

            {activeTab === 'students' && (
              <div>
                <div className="flex justify-between items-center mb-6">
                  <h2 className="text-xl font-semibold text-gray-900">Student Progress - {selectedSection}</h2>
                  <div className="flex items-center space-x-3">
                    <Button size="sm">
                      <Filter className="h-4 w-4 mr-2" />
                      Filter
                    </Button>
                    <Button size="sm">
                      Export Data
                    </Button>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {filteredStudents.map((student) => (
                    <motion.div
                      key={student.studentId}
                      whileHover={{ y: -4 }}
                      transition={{ duration: 0.2 }}
                    >
                      <Card className="p-6 cursor-pointer hover:shadow-lg transition-all duration-300">
                        <div className="flex items-center justify-between mb-4">
                          <div className="flex items-center space-x-3">
                            <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center">
                              <span className="text-blue-600 font-medium text-sm">
                                {student.studentName.split(' ').map(n => n[0]).join('')}
                              </span>
                            </div>
                            <div>
                              <h3 className="font-semibold text-gray-900">{student.studentName}</h3>
                              <p className="text-sm text-gray-500">Last active: {student.lastActivity}</p>
                            </div>
                          </div>
                          <Button variant="ghost" size="sm">
                            <MoreVertical className="h-4 w-4" />
                          </Button>
                        </div>

                        <div className="space-y-3">
                          <div className="flex justify-between items-center">
                            <span className="text-sm text-gray-600">Average Grade</span>
                            <span className={`font-semibold ${getGradeColor(student.averageGrade)}`}>
                              {student.averageGrade}%
                            </span>
                          </div>

                          <div className="flex justify-between items-center">
                            <span className="text-sm text-gray-600">Completion</span>
                            <span className="font-semibold text-gray-900">
                              {student.completedAssignments}/{student.totalAssignments}
                            </span>
                          </div>

                          <div className="w-full bg-gray-200 rounded-full h-2">
                            <div
                              className="bg-blue-600 h-2 rounded-full"
                              style={{ width: `${(student.completedAssignments / student.totalAssignments) * 100}%` }}
                            ></div>
                          </div>

                          <div>
                            <p className="text-sm text-gray-600 mb-1">Strengths:</p>
                            <div className="flex flex-wrap gap-1">
                              {student.strengths.slice(0, 2).map((strength, index) => (
                                <span key={index} className="px-2 py-1 bg-green-100 text-green-800 text-xs rounded-full">
                                  {strength}
                                </span>
                              ))}
                            </div>
                          </div>

                          <div>
                            <p className="text-sm text-gray-600 mb-1">Needs Improvement:</p>
                            <div className="flex flex-wrap gap-1">
                              {student.weakAreas.slice(0, 2).map((area, index) => (
                                <span key={index} className="px-2 py-1 bg-red-100 text-red-800 text-xs rounded-full">
                                  {area}
                                </span>
                              ))}
                            </div>
                          </div>
                        </div>

                        <div className="mt-4 flex space-x-2">
                          <Button size="sm" variant="outline" className="flex-1">
                            <Eye className="h-4 w-4 mr-1" />
                            View Details
                          </Button>
                          <Button size="sm" variant="outline" className="flex-1">
                            <MessageSquare className="h-4 w-4 mr-1" />
                            Message
                          </Button>
                        </div>
                      </Card>
                    </motion.div>
                  ))}
                </div>
              </div>
            )}

            {activeTab === 'submissions' && (
              <div>
                <div className="flex justify-between items-center mb-6">
                  <h2 className="text-xl font-semibold text-gray-900">Recent Submissions</h2>
                  <Button>
                    <CheckCircle className="h-4 w-4 mr-2" />
                    Review All
                  </Button>
                </div>

                <Card className="overflow-hidden">
                  <div className="overflow-x-auto">
                    <table className="min-w-full divide-y divide-gray-200">
                      <thead className="bg-gray-50">
                        <tr>
                          <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Student
                          </th>
                          <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Assignment
                          </th>
                          <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Submitted
                          </th>
                          <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Status
                          </th>
                          <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            AI Graded
                          </th>
                          <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Actions
                          </th>
                        </tr>
                      </thead>
                      <tbody className="bg-white divide-y divide-gray-200">
                        {recentSubmissions.map((submission) => (
                          <tr key={submission.id} className="hover:bg-gray-50">
                            <td className="px-6 py-4 whitespace-nowrap">
                              <div className="flex items-center">
                                <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center mr-3">
                                  <span className="text-blue-600 font-medium text-xs">
                                    {submission.studentName.split(' ').map(n => n[0]).join('')}
                                  </span>
                                </div>
                                <div className="text-sm font-medium text-gray-900">
                                  {submission.studentName}
                                </div>
                              </div>
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap">
                              <div className="text-sm text-gray-900">{submission.assignment}</div>
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap">
                              <div className="text-sm text-gray-500">{submission.submittedAt}</div>
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap">
                              <span className={`px-2 py-1 text-xs rounded-full ${getStatusColor(submission.status)}`}>
                                {submission.status}
                              </span>
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap">
                              {submission.aiGraded ? (
                                <CheckCircle className="h-5 w-5 text-green-500" />
                              ) : (
                                <AlertTriangle className="h-5 w-5 text-yellow-500" />
                              )}
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                              <div className="flex space-x-2">
                                <Button size="sm" variant="outline">
                                  Review
                                </Button>
                                <Button size="sm" variant="ghost">
                                  <MoreVertical className="h-4 w-4" />
                                </Button>
                              </div>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </Card>
              </div>
            )}
          </motion.div>
        </AnimatePresence>
      </div>
    </div>
  );
};
