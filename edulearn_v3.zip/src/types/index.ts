export interface User {
  id: string;
  name: string;
  email: string;
  role: 'student' | 'teacher';
  avatar?: string;
  department?: string;
  year?: number;
  semester?: number;
  rollNumber?: string;
  phone?: string;
  address?: string;
}

export interface Assignment {
  id: string;
  title: string;
  subject: string;
  description: string;
  dueDate: string;
  status: 'pending' | 'completed' | 'overdue' | 'submitted';
  grade?: number;
  maxGrade: number;
  attachments?: string[];
  submissionDate?: string;
  feedback?: string;
  aiGraded?: boolean;
}

export interface CodingProblem {
  id: string;
  title: string;
  difficulty: 'Easy' | 'Medium' | 'Hard';
  description: string;
  examples: {
    input: string;
    output: string;
    explanation?: string;
  }[];
  constraints: string[];
  testCases: {
    input: string;
    expectedOutput: string;
  }[];
  starterCode: {
    [language: string]: string;
  };
}

export interface MCQTest {
  id: string;
  title: string;
  subject: string;
  questions: MCQQuestion[];
  duration: number;
  totalMarks: number;
  dueDate: string;
  status: 'pending' | 'completed' | 'in-progress';
  attempts?: number;
  maxAttempts: number;
}

export interface MCQQuestion {
  id: string;
  question: string;
  options: string[];
  correctAnswer: number;
  explanation?: string;
  marks: number;
}

export interface StudyMaterial {
  id: string;
  title: string;
  subject: string;
  type: 'pdf' | 'video' | 'article' | 'presentation';
  url: string;
  description: string;
  uploadDate: string;
  size?: string;
  duration?: string;
  tags: string[];
}

export interface VirtualLab {
  id: string;
  title: string;
  subject: string;
  description: string;
  type: 'simulation' | 'coding' | 'experiment';
  difficulty: 'Beginner' | 'Intermediate' | 'Advanced';
  estimatedTime: number;
  prerequisites: string[];
  learningOutcomes: string[];
}

export interface Discussion {
  id: string;
  title: string;
  content: string;
  author: string;
  authorId: string;
  subject: string;
  createdAt: string;
  replies: DiscussionReply[];
  likes: number;
  views: number;
  tags: string[];
}

export interface DiscussionReply {
  id: string;
  content: string;
  author: string;
  authorId: string;
  createdAt: string;
  likes: number;
}

export interface Attendance {
  id: string;
  subject: string;
  date: string;
  status: 'present' | 'absent' | 'late';
  duration: number;
  topic: string;
}

export interface Grade {
  id: string;
  subject: string;
  assessment: string;
  marks: number;
  maxMarks: number;
  grade: string;
  date: string;
  feedback?: string;
}

export interface StudyGroup {
  id: string;
  name: string;
  subject: string;
  description: string;
  members: string[];
  createdBy: string;
  createdAt: string;
  meetingLink?: string;
  nextMeeting?: string;
}

export interface Certificate {
  id: string;
  title: string;
  description: string;
  issuedDate: string;
  credentialId: string;
  skills: string[];
  issuer: string;
}

export interface Project {
  id: string;
  title: string;
  description: string;
  subject: string;
  teamMembers: string[];
  status: 'planning' | 'in-progress' | 'completed' | 'submitted';
  dueDate: string;
  progress: number;
  repository?: string;
  documentation?: string[];
}

export interface Internship {
  id: string;
  company: string;
  position: string;
  description: string;
  requirements: string[];
  duration: string;
  stipend?: string;
  location: string;
  applicationDeadline: string;
  status: 'open' | 'applied' | 'closed';
}

export interface StudentProgress {
  studentId: string;
  studentName: string;
  averageGrade: number;
  completedAssignments: number;
  totalAssignments: number;
  attendancePercentage: number;
  weakAreas: string[];
  strengths: string[];
  lastActivity: string;
  totalStudyHours: number;
  projectsCompleted: number;
  certificatesEarned: number;
}

export interface LeaderboardEntry {
  rank: number;
  studentId: string;
  studentName: string;
  score: number;
  timeSpent: number;
  avatar?: string;
}

export interface CalendarEvent {
  id: string;
  title: string;
  description?: string;
  date: string;
  time: string;
  type: 'assignment' | 'exam' | 'class' | 'meeting' | 'event';
  subject?: string;
  location?: string;
}

export interface Note {
  id: string;
  title: string;
  content: string;
  subject: string;
  tags: string[];
  createdAt: string;
  updatedAt: string;
  isShared: boolean;
}

export interface LibraryBook {
  id: string;
  title: string;
  author: string;
  isbn: string;
  subject: string;
  description: string;
  availableCopies: number;
  totalCopies: number;
  dueDate?: string;
  status: 'available' | 'borrowed' | 'reserved';
}
